const webVersion = "v0.6.6b";
const debugMode = false;

var XLogLevel = {
    Information: 0,
    Debuging: 1,
    Warning: 2,
    Critical: 3
}
var DeviceType = {
	Serial: 0,
	Network: 1,
	Deo: 2,
	Whirligig: 3,
	Gamepad: 4,
	XTPWeb: 5,
	None: 6
};

var ConnectionStatus = {
	Connected: 0,
	Disconnected: 1,
	Connecting: 2,
	Error: 3
};

var ChannelType = {
	None: 0,
	Oscillate: 1,
	Ramp: 2,
	HalfOscillate: 3
};

const ChannelTimeType = {
	None: 0,
	Interval: 1,
	Speed: 2
}

const ChannelDimension = {
	None: 0,
	Heave: 1,
	Surge: 2,
	Sway: 3,
	Pitch: 4,
	Roll: 5,
	Yaw: 6
};

var MediaType = {
    PlaylistInternal: 0,
    Video: 1,
    Audio: 2,
    FunscriptType: 3,
    VR: 4,
	ExternalType: 5
};

var ScriptType = {
    MAIN: 0,
    ALTERNATE: 1
};

var ScriptContainerType = {
    BASE: 0,
    MFS: 1,
    ZIP: 2
};

var Roles = {
	DisplayRole: 0,
	DecorationRole: 1,
	EditRole: 2,
	ToolTipRole: 3,
	StatusTipRole: 4,
	WhatsThisRole: 5,
	// Metadata
	FontRole: 6,
	TextAlignmentRole: 7,
	BackgroundRole: 8,
	ForegroundRole: 9
};

var ThumbState = {
    Waiting: 0,
    Loading: 1,
    Error: 2,
    Ready: 3,
    Unknown: 4
}
var NetworkProtocol = {
    UDP: 0,
    WEBSOCKET: 1
};


var MediaActions = {};
var TCodeCommands = [];
var tcodeCommandRows = -1;

var mediaLoading = false;
var refreshPageOnReconnect = false;
var debounceTracker = {};// Use to create timeout handles on the fly.
var settingChangeDebounce;
var wsUri;
var websocket = null;
var xtpConnected = false;
var xtpFormDirty = false;
var userAgent;
var remoteUserSettings;
var mediaListGlobal = [];
var mediaListDisplayed = [];
var selectedMediaItemForMetaData = null;
var selectedMediaItemAltScript = null;
var selectedMediaItemAltScriptCount = 0;
var playingmediaItem;
var playingmediaItemNode;
var webSocket;
var deviceAddress;
var funscriptChannels = [];
//var loadedFunscripts;
var currentChannelIndex = 0;
var outputConnectionStatus = ConnectionStatus.Disconnected;
var selectedInputDevice;
var selectedOutputDevice;
var deviceConnectionStatusInterval;
var serverRetryTimeout;
var serverRetryTimeoutTries = 0;
var videoStallTimeout;
var userFilterCriteria = "";
var userTagFilterCriteria = [];
var filterDebounce;
var enableTextToSpeech = true;
var systemVoices = [];
var speechNotInbrowser = false;
var selectedVoiceIndex = 0;
var speechPitch = 5;
var speechRate = 5;
var speechVolume = 0.5;
var rangeChangeAmount = 100;
const mediaItemHeaderMultiplier = 0.15;
const mediaItemHeaderIconMultiplier = 0.10;

var shufflePlayMode = false;
var shufflePlayModePlayedIndexed = {};
var mediaManagementEnabled = false;

const tagCheckboxesName = "TagCheckbox";
const metadataTagCheckboxesName = "MetadataTagCheckbox";
//var funscriptSyncWorker;
//var useDeoWeb;
//var deoVideoNode;
//var deoSourceNode;


const parseCookie = str =>
str
.split(';')
.map(v => v.split('='))
.reduce((acc, v) => {
	if(v && v[0].trim().length)
		acc[decodeURIComponent(v[0].trim())] = decodeURIComponent(v[1].trim());
return acc;
}, {});

function delete_cookie( name, path, domain ) {
	if( get_cookie( name ) ) {
		document.cookie = name + "=" +
		((path) ? ";path="+path:"")+
		((domain)?";domain="+domain:"") +
		";expires=Thu, 01 Jan 1970 00:00:01 GMT";
	}
}

function get_cookie(name) {
    return document.cookie.split(';').some(c => {
        return c.trim().startsWith(name + '=');
    });
}

document.addEventListener('keyup', keyboardShortcuts);
document.addEventListener('click', destroyMediaContextNode);

var cookies = parseCookie(document.cookie);
if(!cookies.sessionID) {
	document.getElementById("logoutSection").style.display = "none";
	document.getElementById("logoutSectionSpacing").style.display = "none";
	document.getElementById("sessionInfo").hidden = true;
}
getBrowserInformation();
var userAgentIsDeo = userAgent.indexOf("Deo VR") != -1;
var userAgentIsHereSphere = userAgent.indexOf("HereSphere") != -1;
var userAgentIsMobile = userAgent.indexOf("Mobile") != -1;
setDeoStyles(userAgentIsDeo);
var settingsNode = document.getElementById("settingsModal");
const mediaItemSettingsModalNode = document.getElementById("mediaItemSettingsModal");
const metaDataTagsNode = document.getElementById("metaDataTags");// child of mediaItemSettingsModalNode
var thumbsContainerNode = document.getElementById("thumbsContainer");
var videoMediaName = document.getElementById("videoMediaName");

const storedHash = window.localStorage.getItem("storedHash");
var sortByGlobal = JSON.parse(window.localStorage.getItem("sortBy"));
var showGlobal = JSON.parse(window.localStorage.getItem("show"));
if(showGlobal == null) {
	window.localStorage.setItem("show", JSON.stringify("All"));
	showGlobal = "All";
}
var thumbSizeGlobal = JSON.parse(window.localStorage.getItem("thumbSize"));
var selectedSyncConnectionGlobal = JSON.parse(window.localStorage.getItem("selectedSyncConnection"));
var selectedOutputConnectionGlobal = JSON.parse(window.localStorage.getItem("selectedOutputConnection"));
var disableLazyLoad = JSON.parse(window.localStorage.getItem("disableLazyLoad"));
toggleLazyLoad(disableLazyLoad, false);
/* 	if(!thumbSizeGlobal && window.devicePixelRatio == 2.75) {
		thumbSizeGlobal = 400;
	} */
//deviceAddress =  JSON.parse(window.localStorage.getItem("webSocketAddress"));
// if(!deviceAddress)
// 	deviceAddress = "tcode.local";

//document.getElementById("webSocketAddress").value = deviceAddress;

var externalStreaming = JSON.parse(window.localStorage.getItem("externalStreaming"));
toggleExternalStreaming(externalStreaming, false);

const skipToMoneyShotButton = document.getElementById('money-shot');
const skipToNextActionButton = document.getElementById('next-action');
const exitVideoButton = document.getElementById('exit-action');
skipToMoneyShotButton.addEventListener("click", sendSkipToMoneyShot);
skipToMoneyShotButton.addEventListener("click", onSkipToMoneyShotClick);
skipToNextActionButton.addEventListener("click", sendSkipToNextActionClick);
exitVideoButton.addEventListener("click", stopVideoClick);

const playNextButton = document.getElementById('play-next');
playNextButton.addEventListener('click', playNextVideoClick);
const playPreviousButton = document.getElementById('play-previous');
playPreviousButton.addEventListener('click', playPreviousVideoClick);

const xtpWebVersionNode = document.getElementById("webVersion");
xtpWebVersionNode.innerText = webVersion;

var saveStateNode = document.getElementById("saveState");
var mediaReloadRequiredNode = document.getElementById("mediaReloadRequired");

var metaDataSaveStateNode = document.getElementById("metaDataSaveState");
var deviceConnectionStatusRetryButtonNodes = document.getElementsByName("deviceStatusRetryButton");
var deviceConnectionStatusRetryButtonImageNodes = document.getElementsByName("connectionStatusIconImage");
var devicePauseStatusIconButtonNodes = document.getElementsByName("devicePauseStatusButton");
var devicePauseStatusIconButtonImageNodes = document.getElementsByName("devicePauseStatusIconImage");

var progressNode = document.getElementById("statusOutput");
var progressLabelNode = document.getElementById("statusOutputLabel");

var filterInput = document.getElementById('filterInput');
filterInput.value = userFilterCriteria;
var filterInputContainer = document.getElementById('filterInputContainer');

/* 	
	deoVideoNode = document.getElementById("deoVideoPlayer");
	deoSourceNode = document.getElementById("deoVideoSource");
	deoVideoNode.addEventListener("end", onVideoStop); 
	useDeoWeb = JSON.parse(window.localStorage.getItem("useDeoWeb"));

	if(useDeoWeb) {
		toggleUseDeo(useDeoWeb, false);
	} 
*/

setupTextToSpeech();
getServerSettings();

function debug(message) {
	if (debugMode)
		console.log(message);
}
function error(message) {
	console.error(message);
}

function sendWebsocketMessage(command, message) {
	if (websocket && xtpConnected) {
		var obj;
		if (!message) {
			obj = { "command": command }
		} else {
			obj = { "command": command, "message": message }
		}
		websocket.send(JSON.stringify(obj));
	}
}

function onInputDeviceConnectionChange(input, device) {
	selectedInputDevice = device;
	sendInputDeviceConnectionChange(device, input.checked);
	window.localStorage.setItem("selectedSyncConnection", parseInt(device, 10));
	sendMediaState();
}

function onOutputDeviceConnectionChange(input, device) {
	selectedOutputDevice = device;
	sendOutputDeviceConnectionChange(device, input.checked);
	window.localStorage.setItem("selectedOutputConnection", parseInt(device, 10));
	sendMediaState();
}

function sendSystemReady() {
	sendWebsocketMessage("systemReady");
}
function startMetadataProcess() {
	showAlertWindow("Process metadata", "This will set metadata using the algrorith on first scan.<br>Adding smart tags and mfs tags based on the scan.<br>It will not change any user tags set by you.",sendMetadataProcess);
}
function startMetadataCleanProcess() {
	showAlertWindow("Clean metadata", "This will compare the metadata with the currently loaded libraries<br>and delete any that do not exist any more.<br><u><b>DO NOT RUN</b></u> unless you have all your media currently loaded!",sendMetadataCleanProcess);
}

function startThumbCleanupProcess() {
	showAlertWindow("Clean thumbs", "This will go through the thumbs and remove any thumbs where the media<br>do not exist or they not have an image in the media directory.",sendCleanupThumbsProcess);
}
function startClean1024Process() {
	showAlertWindow("Reset 1024", "This will go through all media items and<br>set offsets that are equal to 1024 to 0.<br><br>Continue?",sendClean1024Process);
}
function sendMetadataProcess() {
	sendWebsocketMessage("startMetadataProcess");
	closeAlertWindow();
}
function sendMetadataCleanProcess() {
	sendWebsocketMessage("cleanupMetadata");
	closeAlertWindow();
}
function sendCleanupThumbsProcess() {
	sendWebsocketMessage("cleanupThumbs");
	closeAlertWindow();
}
function sendClean1024Process() {
	sendWebsocketMessage("clean1024");
	closeAlertWindow();
}
function tcodeDeviceConnectRetry() {
	sendWebsocketMessage("connectOutputDevice", { deviceName: remoteUserSettings.connection.output.selectedDevice });
}
function sendTCode(tcode) {
	sendWebsocketMessage("tcode", tcode);
}
function sendTCodeRange(channelName, min, max) {
	sendWebsocketMessage("setChannelRange", { channelName: channelName, min: min, max: max });
}
function sendMediaAction(action) {
	sendWebsocketMessage("mediaAction", action);
}
function sendInputDeviceConnectionChange(device, checked) {
	sendWebsocketMessage("connectInputDevice", { deviceName: device, enabled: checked });
}
function sendOutputDeviceConnectionChange(device, checked) {
	sendWebsocketMessage("connectOutputDevice", { deviceName: device, enabled: checked });
}
function sendSkipToNextActionClick() {
	sendSkipToNextAction();
}
function sendSkipToNextAction() {
	sendWebsocketMessage("skipToNextAction");
}
function sendSkipToMoneyShot() {
	sendWebsocketMessage("skipToMoneyShot");
}
function sendUpdateThumb(item) {
	sendWebsocketMessage("saveSingleThumb", { itemID: item.id, pos: 0 });
}
function sendUpdateThumbAtPos(item) {
	var pos = videoNode.currentTime;
	sendWebsocketMessage("saveSingleThumb", { itemID: item.id, pos: pos });
}
function sendUpdateMoneyShotAtPos(item) {
	var pos = videoNode.currentTime;
	sendWebsocketMessage("setMoneyShot", { itemID: item.id, pos: pos });
}
function sendDeleteMediaItem(item) {
	sendWebsocketMessage("deleteMediaItem", { itemID: item.id });
}
function sendUpdateMetadata(metadataKey) {
	sendWebsocketMessage("processMetadata", metadataKey);
}
function sendQuickExport() {
	setSaveState(null, true);
	sendWebsocketMessage("settingsQuickExport");
}
function sendQuickImport(filename) {
	setSaveState(null, true);
	sendWebsocketMessage("settingsQuickImport", {filename: filename});
}
function setSelectedProfile(profileName) {
	sendWebsocketMessage("changeChannelProfile", profileName);
}
function addChannelProfile(profileName) {
	sendWebsocketMessage("addChannelProfile", profileName);
}
function deleteChannelProfile(profileName) {
	sendWebsocketMessage("deleteChannelProfile", profileName);
}
function cloneChannelProfile(fromName, toName) {
	sendWebsocketMessage("cloneChannelProfile", {fromName: fromName, toName: toName});
}
function sendDeviceHome() {
	sendMediaAction(MediaActions.TCodeHomeAll);
}
function togglePauseAllDeviceActions() {
	sendMediaAction(MediaActions.TogglePauseAllDeviceActions);
}
function sendPlayMedia(obj) {
	sendWebsocketMessage("playMedia", {id: obj.id});
}
function sendStopMedia() {
	sendWebsocketMessage("stopMedia");
}
function sendSwapScript(scriptInfo) {
	sendWebsocketMessage("swapScript", scriptInfo);
}
function settingChange(key, value) {
	if(settingChangeDebounce)
		clearTimeout(settingChangeDebounce);
	settingChangeDebounce = setTimeout(function() {
		sendWebsocketMessage("settingChange", { key: key, value: value });
		// markXTPFormDirty();
	}, 500);
}

function setSaveState(node, saving, error) {
	if(!node)
		node = saveStateNode;
	node.innerText = saving ? "Saving settings..." : "Save success!";
	if(!error) {
		if(!saving) {
			node.style.color = "green";
			setTimeout(() => {
				node.style.visibility = "hidden";
				node.style.opacity = "0";
			}, 5000);
		} else {
			node.style.color = "white";
		}
		node.style.visibility = "visible";
		node.style.opacity = "1";
	} else {
		node.style.visibility = "visible";
		node.style.opacity = "1";
		node.style.color = "red";
		node.innerText = "Save fail";
		node.title = error;
	}
}


function restartXTP() {
	showAlertWindow("Confirm", `Are you sure you want restart XTP? 
		${remoteUserSettings.hasLaunchPass ? `
			<br><br>PLEASE NOTE: XTP is protected by a launch password.
			<br>You will need to go to the pc and enter the password manually for now.` : ''}`, 
	function () {
		sendWebsocketMessage("restartService");
		closeAlertWindow();
		closeSettings();
	});
}
function refreshXTPLibrary() {
	sendWebsocketMessage("reloadLibrary");
	mediaReloadRequiredNode.classList.add('hidden');
}

function buildWebSocketUri(port) {
	var loc = window.location;
	var secure = loc.protocol === 'https:';
	var scheme = secure ? 'wss' : 'ws';

	// Explicit override for unusual proxy setups. Set it from the browser
	// console with: localStorage.setItem('xtpWebSocketUrl', 'wss://myhost.example/ws')
	var override = null;
	try { override = localStorage.getItem('xtpWebSocketUrl'); } catch (e) {}
	if (override) return override;

	// When the page is served over HTTPS, the backend WebSocket server is a
	// separate plain (non-TLS) port that the reverse proxy does not expose to
	// the client, so the upgrade must be routed through the proxy on the same
	// origin, using a dedicated path.
	if (secure) {
		return scheme + '://' + loc.host + '/ws';
	}

	// A plain-HTTP page on a default port (80/none) is also typically behind a
	// reverse proxy.
	if (loc.port === '' || loc.port === '80') {
		return scheme + '://' + loc.host + '/ws';
	}

	// Direct access to the HTTP server on a non-default port: connect straight
	// to the backend WebSocket port.
	return scheme + '://' + loc.hostname + ':' + port;
}

function initWebSocket() {
	try {
		wsUri = buildWebSocketUri(remoteUserSettings.webSocketServerPort);
		
		debug("Connecting to web socket uri: "+wsUri);
		if (typeof MozWebSocket == 'function')
			WebSocket = MozWebSocket;
		if (websocket && websocket.readyState == 1)
			websocket.close();
		websocket = new WebSocket(wsUri);
		websocket.onopen = function (evt) {
			xtpConnected = true;
			stopServerConnectionRetry();
			serverRetryTimeoutTries = 0;
			debug("CONNECTED");
			updateSettingsUI();
			sendMediaState();
			sendSystemReady();
		};
		websocket.onmessage = function (evt) {
			wsCallBackFunction(evt);
			debug("MESSAGE RECIEVED: " + evt.data);
		};
		websocket.onclose = function (evt) {
			debug("DISCONNECTED");
			xtpConnected = false;
			startServerConnectionRetry();
		};
		websocket.onerror = function (evt) {
			console.log('ERROR: ' + evt.data + ", Address: " + wsUri);
			xtpConnected = false;
			startServerConnectionRetry();
		};
	} catch (exception) {
		console.log('ERROR: ' + exception + ", Address: " + wsUri);
		xtpConnected = false;
		startServerConnectionRetry();
	}
}

function wsCallBackFunction(evt) {
	try {
		var data = JSON.parse(evt.data);
		switch (data["command"]) {
			case "messageSend": {
					var obj = data["message"];
					const message = obj["message"].replaceAll("\n", "<br>");
					const level = obj["loglevel"]
					switch(level) {
						case XLogLevel.Debuging:
							break
						case XLogLevel.Critical:
							systemError(message);
							break
						case XLogLevel.Information:
							showAlertWindow("Message", message);
							break
						case XLogLevel.Warning:
							systemWarning(message);
							break
						default:
							break;
					}
				}
				break;
			case "userError":
				userError(data["message"].replaceAll("\n", "<br>"));
				break;
			case "userWarning":
				userWarning(data["message"].replaceAll("\n", "<br>"));
				break;
			case "systemError":
				systemError(data["message"].replaceAll("\n", "<br>"));
				break;
			case "systemWarning":
				systemWarning(data["message"].replaceAll("\n", "<br>"));
				break;
			case "settingChange":
				var obj = data["message"];
				var key = obj["key"];
				var value = obj["value"];
				onSaveSuccess();
				Settings.onSaveSuccess(key, value);
				break;
			case "settingsExported":
				var obj = data["message"];
				var message = obj["message"];
				var path = obj["path"];
				var success = obj["success"];
				onSettingsExported(message, path, success);
				break;
			case "settingsImported":
				var obj = data["message"];
				var message = obj["message"];
				var path = obj["path"];
				var success = obj["success"];
				onSettingsImported(message, path, success);
				break;
			case "stopAllMedia":
				stopVideo();
				break;
			case "outputDeviceStatus":
				var status = data["message"];
				var deviceName = status["deviceName"];
				setOutputConnectionStatus(deviceName, status["status"], status["message"]);
				break;
			case "inputDeviceStatus":
				var status = data["message"];
				var deviceName = status["deviceName"];
				setInputConnectionStatus(deviceName, status["status"], status["message"]);
				break;
			case "mediaLoaded":
				onMediaLoaded();
				break;
			case "mediaLoading":
				setMediaLoading();
				break;
			case "mediaLoadingStatus":
				setMediaLoadingStatus(data["message"]);
				break;
			case "updateThumb":
				var message = data["message"];
				var mediaElement = document.getElementById(message.id);
				if (mediaElement) {
					var imageElement = mediaElement.getElementsByClassName("media-thumb-nail")[0];
					var src = "/thumb/" + message.thumb + "?" + new Date().getTime();
					if(imageElement.src.length > 0)
						imageElement.src = src;
					else
						imageElement.dataset.src = src;
					if (message.errorMessage)
						imageElement.title = message.errorMessage;
					var index = mediaListGlobal.findIndex(x => x.id === message.id);
					mediaListGlobal[index].relativeThumb = "/thumb/" + message.thumb;
					mediaListGlobal[index].thumbFileExists = true;
				}
				break;
			case "updateItem":
				var message = data["message"];
				var libraryItem = message["item"];
				var roles = message["roles"];
				updateItem(libraryItem, roles);
				break;
			case "addItem":
				var message = data["message"];
				var libraryItem = message["item"];
				var roles = message["roles"];
				addItem(libraryItem);
				break;
			case "deleteItem":
				var message = data["message"];
				var itemID = message["itemID"];
				deleteItem(itemID);
				break;
			case "textToSpeech":
				var message = data["message"];
				onTextToSpeech(message);
				break;
			case "skipToNextAction":
				var message = data["message"];
				skipVideoTo(message);
				break;
			case "skipToMoneyShot":
				onSkipToMoneyShot();
				break;
			case "logout":
				logout();
				break;
			case "channelProfileChanged":
				getServerChannels();
				break;
			case "statusOutput":
				var messageObj = data["message"];
				var message = messageObj["message"]
				var percentage = messageObj["percentage"]
				setStatusOutput(message, percentage);
				break;
			case "tagsUpdate":
				var messageObj = data["message"];
				var smartTags = messageObj["smartTags"]
				var userTags = messageObj["userTags"]
				remoteUserSettings["allTags"] = [];
				remoteUserSettings["allTags"].push(...userTags, ...smartTags);
				remoteUserSettings["userTags"] = []
				remoteUserSettings["userTags"].push(...userTags);
				remoteUserSettings["smartTags"] = []
				remoteUserSettings["smartTags"].push(...smartTags);
				setupSystemTags();
				break;
			case "channelPositionChange":
				var messageObj = data["message"];
				var channel = messageObj["channel"];
				var position = parseInt(messageObj["position"]);
				var time = parseInt(messageObj["time"]);
				var timeType = parseInt(messageObj["timeType"]);
				setChannelStatus(channel, position, time, timeType);
				break;
			case "mediaAction":
				var mediaAction = data["message"];
				// switch(mediaAction["mediaAction"]) {
				// 	case MediaActions.TogglePauseAllDeviceActions: // For not pause device update is handled through the syncHandler in the case "scriptTogglePaused"
				// 		setPauseScriptStatus(mediaAction["value"]);
				// 		setDevicePauseStatus(mediaAction["value"]);
				// 		break;
				// }
				break;
			case "scriptTogglePaused":
				var messageObj = data["message"];
				setPauseScriptStatus(messageObj.isPaused);
				setDevicePauseStatus(messageObj.isPaused);
				break;
			case "changePlayrate":
				var messageObj = data["message"];
				break;
			case "metadataProcessingFinished":
				getServerLibrary();
				break;

		}
	}
	catch (e) {
		if(typeof e == "string")
			error(e);
		else
			error(e.toString());
	}
}

function setStatusOutput(message, percentage) {
	if(!message && !progressNode.classList.contains("hidden-visibility")) {
		progressNode.classList.add("hidden-visibility")
		progressLabelNode.classList.add("hidden-visibility");
	} else if(message && progressNode.classList.contains("hidden-visibility")) {
		progressNode.classList.remove("hidden-visibility");
		progressLabelNode.classList.remove("hidden-visibility");
	}
	// !message ? progressNode.classList.add("hidden-visibility") : progressNode.classList.remove("hidden-visibility");
	// !message ? progressLabelNode.classList.add("hidden-visibility") : progressLabelNode.classList.remove("hidden-visibility");
	progressLabelNode.innerText = (!message ? "" : message) + (percentage > -1 ? ": "+round(percentage, 2)+"%" : "");
	progressNode.value = (percentage > -1 ? percentage : 0);
}
function setMediaLoading() {
	mediaLoading = true;
	stopVideo();
	clearMediaList();
	var mediaLoadingElement = document.getElementById("mediaLoading");
	mediaLoadingElement.style.display = "flex"
	var noMediaElement = document.getElementById("noMedia");
	var mediaLoadingElements = document.getElementsByName("mediaLoadingIcon");
	for (let index = 0; index < mediaLoadingElements.length; index++) {
		const element = mediaLoadingElements[index];
		element.classList.remove("hidden");
	}
	noMediaElement.hidden = true;
	var refreshMediaLibraryButtons = document.getElementsByName("refreshXTPLibraryButton");
	for (let index = 0; index < refreshMediaLibraryButtons.length; index++) {
		const element = refreshMediaLibraryButtons[index];
		element.disabled = true;
	}
	var mediaLoadingStatusElementa = document.getElementsByName("mediaLoadingStatus");
	for (let index = 0; index < mediaLoadingStatusElementa.length; index++) {
		const element = mediaLoadingStatusElementa[index];
		element.innerText = "";
		element.classList.remove("hidden");
	}
}

function onMediaLoaded() {
	var mediaLoadingElement = document.getElementById("mediaLoading");
	mediaLoadingElement.style.display = "none"
	mediaLoading = false;
	var mediaLoadingElements = document.getElementsByName("mediaLoadingIcon");
	for (let index = 0; index < mediaLoadingElements.length; index++) {
		const element = mediaLoadingElements[index];
		element.classList.add("hidden");
	}
	var refreshMediaLibraryButtons = document.getElementsByName("refreshXTPLibraryButton");
	for (let index = 0; index < refreshMediaLibraryButtons.length; index++) {
		const element = refreshMediaLibraryButtons[index];
		element.disabled = false;
	}
	var mediaLoadingStatusElementa = document.getElementsByName("mediaLoadingStatus");
	for (let index = 0; index < mediaLoadingStatusElementa.length; index++) {
		const element = mediaLoadingStatusElementa[index];
		element.innerText = "";
		element.classList.add("hidden");
	}
	getServerLibrary();
}

function setMediaLoadingStatus(status) {
	var mediaLoadingElement = document.getElementById("loadingStatus");
	mediaLoadingElement.innerText = status;
	var mediaLoadingStatusElementa = document.getElementsByName("mediaLoadingStatus");
	for (let index = 0; index < mediaLoadingStatusElementa.length; index++) {
		const element = mediaLoadingStatusElementa[index];
		element.innerText = status;
	}
}

function onResizeVideo() {
	// if(!videoContainer.classList.contains('video-fixed-container'))
	// 	thumbsContainerNode.style.maxHeight = "calc(100vh - " + (+videoNode.offsetHeight + 100) + "px)";
	// else {
	// 	thumbsContainerNode.style.maxHeight = "calc(100vh - 100px)";
	// }
}


function getBrowserInformation() {
	var nAgt = navigator.userAgent;
	var browserName;
	var fullVersion;
	var majorVersion;
	var nameOffset, verOffset, ix;

	// In Opera, the true version is after "Opera" or after "Version"
	if ((verOffset = nAgt.indexOf("Opera")) != -1) {
		browserName = "Opera";
		fullVersion = nAgt.substring(verOffset + 6);
		if ((verOffset = nAgt.indexOf("Version")) != -1)
			fullVersion = nAgt.substring(verOffset + 8);
	}
	// In MSIE, the true version is after "MSIE" in userAgent
	else if ((verOffset = nAgt.indexOf("MSIE")) != -1) {
		browserName = "Microsoft Internet Explorer";
		fullVersion = nAgt.substring(verOffset + 5);
	}
	// In Chrome, the true version is after "Chrome" 
	else if ((verOffset = nAgt.indexOf("Chrome")) != -1) {
		browserName = "Chrome";
		fullVersion = nAgt.substring(verOffset + 7);
	}
	// In Safari, the true version is after "Safari" or after "Version" 
	else if ((verOffset = nAgt.indexOf("Safari")) != -1) {
		browserName = "Safari";
		fullVersion = nAgt.substring(verOffset + 7);
		if ((verOffset = nAgt.indexOf("Version")) != -1)
			fullVersion = nAgt.substring(verOffset + 8);
	}
	// In Firefox, the true version is after "Firefox" 
	else if ((verOffset = nAgt.indexOf("Firefox")) != -1) {
		browserName = "Firefox";
		fullVersion = nAgt.substring(verOffset + 8);
	}
	// In most other browsers, "name/version" is at the end of userAgent 
	else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) <
		(verOffset = nAgt.lastIndexOf('/'))) {
		browserName = nAgt.substring(nameOffset, verOffset);
		fullVersion = nAgt.substring(verOffset + 1);
		if (browserName.toLowerCase() == browserName.toUpperCase()) {
			browserName = navigator.appName;
		}
	}
	// trim the fullVersion string at semicolon/space if present
	if ((ix = fullVersion.indexOf(";")) != -1)
		fullVersion = fullVersion.substring(0, ix);
	if ((ix = fullVersion.indexOf(" ")) != -1)
		fullVersion = fullVersion.substring(0, ix);

	majorVersion = parseInt('' + fullVersion, 10);
	if (isNaN(majorVersion)) {
		fullVersion = '' + parseFloat(navigator.appVersion);
		majorVersion = parseInt(navigator.appVersion, 10);
	}

	var divnode = document.createElement("div");
	divnode.innerHTML = ''
		+ 'Browser name  = ' + browserName + '<br>'
		+ 'Full version  = ' + fullVersion + '<br>'
		+ 'Major version = ' + majorVersion + '<br>'
		+ 'navigator.userAgent = ' + navigator.userAgent + '<br>';
	userAgent = navigator.userAgent;
	document.getElementById("browserInfo").appendChild(divnode)
}
function setDeoStyles(isDeo) {
	if (isDeo) {
		var checkboxes = document.querySelectorAll("input[type='checkbox']");
		for (var i = 0; i < checkboxes.length; i++) {
			checkboxes[i].classList.remove("styled-checkbox")
		}
	} else {
		var checkboxes = document.getElementsByClassName("input[type='checkbox']");
		for (var i = 0; i < checkboxes.length; i++) {
			checkboxes[i].classList.add("styled-checkbox");
		}
	}
}
/* 
function onResizeDeo() {
	if(useDeoWeb) {
		thumbsContainerNode.style.maxHeight = "calc(100vh - "+ (+deoVideoNode.offsetHeight + 120) + "px)";
	}
} 
*/
function parseHttpError(preText, xhr) {
// } else if(status == 401) {
// 	if(storedHash) {
// 		checkPass();
// 	} else {
// 		window.location.replace(window.location.origin);
// 	}
// } else {
	// startServerConnectionRetry();
	const status = xhr.status;
	let errorText = preText+ ": ";
	if (status === 401) { 
		if(storedHash) {
			checkPass();
		} else {
			window.location.replace(window.location.origin);
		}
		// userError("System authorization has expired. Refresh the page to continue.");
	} else if(xhr.statusText && xhr.statusText.length > 0) {
		systemError(errorText + xhr.statusText);
	} else if(typeof status === "object" || typeof xhr.response === "object" ) {
		if(typeof xhr.response === "object") {
			const obj = JSON.parse(xhr.response);
			if(obj.message && obj.message.length > 0) {
				systemError(errorText + obj.message);
				return;
			} 
		} else if(status.statusText && status.statusText.length > 0) {
			systemError(errorText + status.statusText);
			return;
		}
		systemError(errorText + typeof status === "object" ? JSON.stringify(status) : JSON.stringify(xhr.response));
	} else {
		systemError(errorText + "Unknown error: "+ status);
	}
}
function logout() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/logout", true);
	xhr.responseType = 'json';
	xhr.onload = function () {
		var status = xhr.status;
		if (status === 200) {
			window.localStorage.removeItem("storedHash");
			window.sessionStorage.clear();
			delete_cookie("sessionID");
			cookies.sessionID = undefined;
			window.location.replace(window.location.origin);
		} else {
			parseHttpError("Error logging out", xhr);
		}
	};
	xhr.onerror = function () {
		parseHttpError("Error logging out", xhr);
	};
	xhr.send();
}

function checkPass() {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', "/auth", true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            var status = xhr.status;
            if (status == 200) {
				startServerConnectionRetry();
            } else {
				parseHttpError("Error checking pass", xhr);
			}
        }
    }
    xhr.onerror = function () {
		parseHttpError("Error checking pass", xhr);
    };
    if(storedHash) {
        xhr.send("{\"hashedPass\":\""+storedHash+"\", \"remember\":\""+!!storedHash+"\"}");
    } else
        alert("Invalid password");
}
function confirmDeleteExported(filename)
{
	showAlertWindow("Delete", "Are you sure you wish to delete the file:<br>"+ filename + "?", () => deleteExported(filename));
}
function confirmImportExported(filename)
{
	showAlertWindow("Restore", "Are you sure you wish to restore all settings to the file:<br>"+ filename + "?<br>The application will automatically restart after a successful import.", () => restoreExported(filename));
}
function deleteExported(filename) {
	setSaveState(null, true);
    var xhr = new XMLHttpRequest();
    xhr.open('POST', "/exported", true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            var status = xhr.status;
            if (status == 200) {
				setSaveState(null, false);
				getExported();
            } else {
				parseHttpError("Error deleting exported settings file", xhr);
			}
        }
		closeAlertWindow();
    }
    xhr.onerror = function () {
		parseHttpError("Error deleting exported settings file", xhr);
    };
    xhr.send(JSON.stringify({filename:filename}));
}
function restoreExported(filename)
{
	sendQuickImport(filename);
	closeAlertWindow();
}
function getExported() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/exported", true);
	xhr.responseType = 'json';
	xhr.onload = function (evnt, retry) {
		var status = xhr.status;
		const files = xhr.response;
		const tableNode = document.getElementById("exportedSettingFiles");
		removeAllChildNodes(tableNode);
		const header = document.createElement("thead");

		const filenameHeader = document.createElement("th");
		filenameHeader.innerText = "File name";
		header.appendChild(filenameHeader);

		const restoreHeader = document.createElement("th");
		restoreHeader.innerText = "";
		header.appendChild(restoreHeader);

		const deleteHeader = document.createElement("th");
		deleteHeader.innerText = "";
		header.appendChild(deleteHeader);

		tableNode.appendChild(header);

		const body = document.createElement("tbody");
		if (status === 200 && files && Array.isArray(files) && files.length > 0) {
			const filesSorted = files.sort((a,b) => {
				// return (a.date < b.date) ? -1 : ((a.date > b.date) ? 1 : 0);//ASC
				return (a.date > b.date) ? -1 : ((a.date < b.date) ? 1 : 0);//DSC
			});
			const filenames = filesSorted.map(x => x.name);
				filenames.forEach(x => {
					const tr = document.createElement("tr");

					const tdDownload = document.createElement("td");
					const tdSpan = document.createElement("span");
					const downloadlink = document.createElement("a");
					downloadlink.innerText = x;
					downloadlink.href = "/exported/" + x;
					downloadlink.setAttribute("download", x);
					downloadlink.setAttribute("target", "_blank");
					tdSpan.appendChild(downloadlink);
					tdSpan.classList.add("exported-download-link");
					tdSpan.setAttribute("title", "Download:\n"+x);
					tdDownload.appendChild(tdSpan);
					tr.appendChild(tdDownload);

					const tdImport = document.createElement("td");
					const importButton = document.createElement("button");
					importButton.innerText = "Restore";
					importButton.onclick = () => confirmImportExported(x);
					tdImport.appendChild(importButton);
					tr.appendChild(tdImport);

					const tdDelete = document.createElement("td");
					const deleteButton = document.createElement("button");
					deleteButton.innerText = "X";
					deleteButton.onclick = () => confirmDeleteExported(x);
					tdDelete.appendChild(deleteButton);
					tr.appendChild(tdDelete);

					body.appendChild(tr);
				});
		} else {
			const tr = document.createElement("tr");
			const tdDownload = document.createElement("td");
			const tdSpan = document.createElement("span");
			tdSpan.innerHTML = status === 200 ? "No backups exist" : xhr.response.message;
			tdSpan.setAttribute("title", xhr.response.message);
			tdSpan.classList.add("exported-download-link");
			tdDownload.appendChild(tdSpan);
			tr.appendChild(tdDownload);
			const tdDelete = document.createElement("td");
			tr.appendChild(tdDelete);
			body.appendChild(tr);
		}
		tableNode.appendChild(body);
	}.bind(this);
	xhr.onerror = function() {
		parseHttpError("Error getting exported settings file", xhr);
	};
	xhr.send();
}

function getServerSettings(retry) {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/settings", true);
	xhr.responseType = 'json';
	xhr.onload = function (evnt, retry) {
		var status = xhr.status;
		if (status === 200) {
			// if(refreshPageOnReconnect) {
			// 	//setSaveState(null, false);
			// 	window.location.reload();
			// 	return;
			// }
			getMediaActions();
			getTCodeCommand();
			getExported();
			remoteUserSettings = xhr.response;

			document.getElementById("xteVersion").innerText = remoteUserSettings["xteVersion"];

			// document.getElementById("scheduleLibraryLoadEnabled").checked = remoteUserSettings["settings"]["scheduleLibraryLoadEnabled"];
			// document.getElementById("scheduleLibraryLoadTime").value = remoteUserSettings["settings"]["scheduleLibraryLoadTime"];
			// document.getElementById("scheduleLibraryLoadFullProcess").checked = remoteUserSettings["settings"]["scheduleLibraryLoadFullProcess"];
			// document.getElementById("processMetadataOnStart").checked = remoteUserSettings["settings"]["processMetadataOnStart"];
			// document.getElementById("scheduleSettingsSync").checked = remoteUserSettings["settings"]["scheduleSettingsSync"];
			// document.getElementById("disableUDPHeartBeat").checked = remoteUserSettings["settings"]["disableUDPHeartBeat"];
			// document.getElementById("httpChunkSizeMB").value = remoteUserSettings["settings"]["httpChunkSizeMB"];

			Settings.load(remoteUserSettings);

			setupChannelData();

			setupSystemTags();
			
			initWebSocket();
		// } else if(status == 401) {
		// 	if(storedHash) {
		// 		checkPass();
		// 	} else {
		// 		window.location.replace(window.location.origin);
		// 	}
		} else {
			// startServerConnectionRetry();

			parseHttpError("Error getting server settings", xhr);
		}
	}.bind(this);
	xhr.onerror = function(evnt, retry) {
	/* 	if(!retry)
			systemError("Error getting settings: "+ xhr.responseText);
		else */
		startServerConnectionRetry();
	};
	xhr.send();
}

function getMediaActions() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/mediaActions", true);
	xhr.responseType = 'json';
	xhr.onload = function (evnt) {
		var status = xhr.status;
		if (status === 200) {
			MediaActions = xhr.response;
		} else {
			parseHttpError("Error getting media actions", xhr);
		}
	}.bind(this);
	xhr.onerror = function(evnt) {
		parseHttpError("Error getting media actions", xhr);
	};
	xhr.send();
}

function getTCodeCommand() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/tcodeCommands", true);
	xhr.responseType = 'json';
	xhr.onload = function (evnt) {
		var status = xhr.status;
		if (status === 200) {
			TCodeCommands = xhr.response.commands;
			setupTCodeCommands(TCodeCommands.commands);
		} else {
			parseHttpError("Error getting tcode commands", xhr);
		}
	}.bind(this);
	xhr.onerror = function(evnt) {
		parseHttpError("Error getting tcode commands", xhr);
	};
	xhr.send();
}

function getServerChannels() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/channels", true);
	xhr.responseType = 'json';
	xhr.onload = function (evnt) {
		var status = xhr.status;
		if (status === 200) {
			var response = xhr.response;
			remoteUserSettings.availableChannels = response.availableChannels;
			remoteUserSettings.selectedChannelProfile = response.selectedChannelProfile;
			remoteUserSettings.allChannelProfileNames = response.allChannelProfileNames;
			setupChannelData();
			updateChannelsUI();
		} else {
			parseHttpError("Error getting channels", xhr);
		}
	}.bind(this);
	xhr.onerror = function(evnt) {
		parseHttpError("Error getting channels", xhr);
	};
	xhr.send();
}

function setupChannelData() {
	// Used to get funscripts from server?
	funscriptChannels = Object.keys(remoteUserSettings["availableChannels"])
		.map(function (k) {
			return remoteUserSettings["availableChannels"][k]["channel"];
		});
	remoteUserSettings.availableChannelsArray = Object.keys(remoteUserSettings["availableChannels"])
		.map(function (k) {
			return remoteUserSettings["availableChannels"][k];
		});
	funscriptChannels.sort();
}

function setupSystemTags() {
	const tags = remoteUserSettings["allTags"];
	const tagsFIlterNode = document.getElementById("tagFilterOptions");
	removeAllChildNodes(tagsFIlterNode);
	removeAllChildNodes(metaDataTagsNode);
	const optionsContainer = document.createElement("div");
	const ornode = createCheckBoxDiv("tagFilterORChk", "OR", false, "OR", onFilterByTagClicked);
	ornode.setAttribute("title", "If checked, the selected tags will be inclusive.")
	optionsContainer.appendChild(ornode);
	tagsFIlterNode.appendChild(optionsContainer);
	const containter = document.createElement("div");
	containter.classList.add("side-action-tag-filter-container")
	tagsFIlterNode.appendChild(containter);
	tags.forEach((x, i) => {
		containter.appendChild(createCheckBoxDiv(x+tagCheckboxesName+i, tagCheckboxesName, x, x, onFilterByTagClicked));

		metaDataTagsNode.appendChild(createCheckBoxDiv(x+metadataTagCheckboxesName+i, metadataTagCheckboxesName, x, x, onMetadataTagCheckboxClicked));
	});

	const userTagsSelect = document.getElementById("systemTagsSelect");
	while(userTagsSelect.options.length > 0) {
		userTagsSelect.options.remove(userTagsSelect.options.length - 1);
	}
	const userTags = remoteUserSettings["userTags"];
	userTags.forEach((x, i) => {
		const option = document.createElement("option");
		option.value = x;
		option.innerText = x;
		userTagsSelect.options.add(option);
	});
	
	const smartTagsSelect = document.getElementById("smartTagsSelect");
	while(smartTagsSelect.options.length > 0) {
		smartTagsSelect.options.remove(smartTagsSelect.options.length - 1);
	}
	const smartTags = remoteUserSettings["smartTags"];
	smartTags.forEach((x, i) => {
		const option = document.createElement("option");
		option.value = x;
		option.innerText = x;
		smartTagsSelect.options.add(option);
	});
}

function systemTagsSelectChange(selectElement) {
	document.getElementById("removeTagButton").disabled = selectElement.options.selectedIndex == -1;
}
function smartagsSelectChange(selectElement) {
	document.getElementById("removeSmartTagButton").disabled = selectElement.options.selectedIndex == -1;
}

function addSystemTag(smartMode) {
	var callback = function(value) {
		systemTagAdded(value, smartMode);
	}
	//var name = prompt(smartMode ? 'Smart tag name' : 'Tag name');
	showGetTextWindow(smartMode ? 'Add smart tag' : 'Add tag', "Name", callback);
}

function systemTagAdded(name, smartMode) {
	if(!name || !name.trim().length) {
		showAlertWindow("Empty", `Tag cant be empty!`);
		return;
	}
	let tags = remoteUserSettings[smartMode ? "smartTags" : "userTags"];
	if(tags.findIndex(x => x == name) > -1) {
		showAlertWindow("Tag exists", `Tag '${name}' already exists!`);
		return;
	}
	const otherTagName = !smartMode ? "smartTags" : "userTags";
	let other = remoteUserSettings[otherTagName];
	if(other.findIndex(x => x == name) > -1) {
		showAlertWindow("Tag exists", `Tag '${name}' already exists in ${otherTagName}!`);
		return;
	}
	const settingMemberName = smartMode ? "smartTagsToAdd" : "tagsToAdd";
	if(!remoteUserSettings[settingMemberName])
		remoteUserSettings[settingMemberName] = [];
	remoteUserSettings[settingMemberName].push(name);
	const systemTagsSelect = document.getElementById(smartMode ? "smartTagsSelect" : "systemTagsSelect");
	const option = document.createElement("option");
	option.value = name;
	option.innerText = name;
	systemTagsSelect.options.add(option);
	if(smartMode)
		mediaReloadRequiredNode.classList.remove('hidden');
	closeTextWindow();

	//tags.push(name);

	markXTPFormDirty();
}

function removeSystemTags(smartMode) {
	let tags = remoteUserSettings[smartMode ? "smartTags" : "userTags"];
	const systemTagsSelect = document.getElementById(smartMode ? "smartTagsSelect" : "systemTagsSelect");
	const settingMemberName = smartMode ? "smartTagsToRemove" : "tagsToRemove";
	if(!remoteUserSettings[settingMemberName])
		remoteUserSettings[settingMemberName] = [];
	while(systemTagsSelect.options.selectedIndex > -1) {
		const opt = systemTagsSelect.options[systemTagsSelect.options.selectedIndex];
		remoteUserSettings[settingMemberName].push(opt.value);
		//tags.splice(tags.findIndex(x => x == opt.value), 1);
		systemTagsSelect.options.remove(systemTagsSelect.options.selectedIndex);
	}
	markXTPFormDirty();
}

function setupTCodeCommands(commands)
{
	const actionButtonsDivNodes = document.getElementsByClassName("side-action-tcode-action-container");
	for(let i=0; i < actionButtonsDivNodes.length; i++)
	{
		removeAllChildNodes(actionButtonsDivNodes[i])
	}
	if(!commands)
		commands = TCodeCommands;
	if(!commands || commands.length == 0) 
	{
		const infoDiv = document.createElement("div");
		infoDiv.innerHTML = "No TCode commands found.<br>Visit the settings to add some."
		for(let i=0; i < actionButtonsDivNodes.length; i++)
		{
			actionButtonsDivNodes[i].appendChild(infoDiv)
		}
	} 
	else 
	{
		commands.forEach(x => 
			{
			const button = document.createElement("button");
			button.innerText = x["name"];
			button.onclick = function () { sendTCode(x["command"]); };
			//button.style = "align-self: center;"
			button.classList.add("side-action-tcode-action-button")
			button.hidden = x["hidden"];
			button.name = "tcodeCommandButton";
			button.title = x["command"];
			for(let i=0; i < actionButtonsDivNodes.length; i++)
			{
				actionButtonsDivNodes[i].appendChild(button)
			}
		});
	}

	// Setup
	markTCodeCommandFormClean();
	const setupNode = document.getElementById("tcodeCommandsSetupBody");
	removeAllChildNodes(setupNode);
	tcodeCommandRows = -1;
	const setupForm = document.createElement("form");
	setupForm.id = "tcodeCommandsSetupForm";
	const table = document.createElement("table");
	table.classList.add("tcodeCommandsSetupTable");
	const thead = document.createElement("thead");
	const thName = document.createElement("th");
	thName.innerText = "Name";
	thead.appendChild(thName);
	const thCommand = document.createElement("th");
	thCommand.innerText = "Command";
	thead.appendChild(thCommand);
	const thhidden = document.createElement("th");
	thhidden.innerText = "Hidden";
	thead.appendChild(thhidden);
	const thDelete = document.createElement("th");
	thDelete.innerText = "";
	thead.appendChild(thDelete);
	table.appendChild(thead);
	const tbody = document.createElement("tbody");
	tbody.id = "tcodeCommandsSetupTableBody";
	table.appendChild(tbody);
	setupForm.appendChild(table)
	setupNode.appendChild(setupForm);
	setupTCodeCommandsSetup(commands);
}

function setupTCodeCommandsSetup(commands)
{
	const tbody = document.getElementById("tcodeCommandsSetupTableBody");
	if(!commands)
		commands = TCodeCommands;
	if(!commands || commands.length == 0)
	{
		addNoTCodeCommandsFoundRow();
		return;
	}
	commands.forEach(x => {
		const tr = getTCodeCommandTableRow(x);
		tbody.appendChild(tr);
	});
}

function addNoTCodeCommandsFoundRow()
{
	const existing = document.getElementById("noTCodeCommandsInSetup");
	if(existing)
		return;
	const tbody = document.getElementById("tcodeCommandsSetupTableBody");
	const tr = document.createElement("tr");
	tr.id = "noTCodeCommandsInSetup"
	const tdName = document.createElement("td");
	tdName.innerHTML = "No TCode commands found.";
	tr.appendChild(tdName);
	tbody.appendChild(tr);
}

function removeNoTCodeCommandsFoundRow()
{
	const existing = document.getElementById("noTCodeCommandsInSetup");
	if(!existing)
		return;
	existing.remove();
}

function getTCodeCommandTableRow(command)
{
	tcodeCommandRows++;
	const rowID = tcodeCommandRows;
	if(!command) {
		command = {name: "new"+rowID, command: "", hidden: false};
		TCodeCommands.push(command);
	}
	const tr = document.createElement("tr");
	tr.id = "tcodeCommandRow"+rowID;
	tr.setAttribute("name", "tcodeCommandRow");
	const tdName = document.createElement("td");
	const inputName = document.createElement("input");
	inputName.required = true;
	inputName.value = command["name"];
	inputName.id = "tcodeCommandNameInput"+rowID
	inputName.name = "tcodeCommandNameInput"
	inputName.oninput = function () {
		if(debounceTracker[inputName.id])
			clearTimeout(debounceTracker[inputName.id]);
		debounceTracker[inputName.id] = setTimeout(function () {
			let index = TCodeCommands.findIndex(x => x.name == command["name"]);
			if(index > -1) {
				const tcodeCommandNameInputs = document.getElementsByName("tcodeCommandNameInput");
				const duplicateIndex = [...tcodeCommandNameInputs].findIndex(node => node.id != inputName.id && node.value.length && node.value == inputName.value);
				if(duplicateIndex > -1)
				{
					const error = `Name: ${inputName.value} already exists!`;
					userError(error);
					inputName.setCustomValidity(error);
					return;
				}
				else {
					inputName.setCustomValidity("");
				}
				TCodeCommands[index].name = inputName.value;
				checkTCodeCommandSetupFormDirty();
			} else {
				systemError(`There was an error. Command not found ${command["name"]}. Try refreshing the page.`)
			}
			debounceTracker[inputName.id] = null;
		}, 500);
	};
	tdName.appendChild(inputName);
	tr.appendChild(tdName);

	const tdCommand = document.createElement("td");
	const inputCommand = document.createElement("input");
	inputCommand.required = true;
	inputCommand.value = command["command"];
	inputCommand.id = "inputTCodeCommandCommand"+rowID
	inputCommand.oninput = function () {
		if(debounceTracker[inputCommand.id])
			clearTimeout(debounceTracker[inputCommand.id]);
		debounceTracker[inputCommand.id] = setTimeout(function () {
			const index = TCodeCommands.findIndex(x => x.name == command["name"]);
			if(index > -1) {
				TCodeCommands[index].command = inputCommand.value;
				checkTCodeCommandSetupFormDirty();
			} else {
				systemError(`There was an error. Command not found ${command["name"]}. Try refreshing the page.`)
			}
			debounceTracker[inputCommand.id] = null;
		}, 500);
	};
	tdCommand.appendChild(inputCommand);
	tr.appendChild(tdCommand);

	const tdhidden = document.createElement("td");
	const hiddenCheck = document.createElement("input");
	hiddenCheck.type = "checkbox";
	hiddenCheck.checked = command["hidden"];
	hiddenCheck.onclick = function() {
		if(!command["name"].length)
			return;
		const index = TCodeCommands.findIndex(x => x.name == command["name"]);
		if(index > -1) {
			TCodeCommands[index].hidden = hiddenCheck.checked;
			checkTCodeCommandSetupFormDirty();
		} else {
			systemError(`There was an error. Command not found ${command["name"]}. Try refreshing the page.`)
		}
	};
	tdhidden.appendChild(hiddenCheck);
	tr.appendChild(tdhidden);
	
	const tdDelete = document.createElement("td");
	const buttonDelete = document.createElement("button");
	buttonDelete.innerText = "X";
	buttonDelete.type = "button";
	buttonDelete.onclick = function() {
		if(!inputName.value.length)
		{
			tr.remove();
			const rows = document.getElementsByName("tcodeCommandRow");
			if(!rows?.length) {
				addNoTCodeCommandsFoundRow();
			}
			return;
		}
		showAlertWindow("Delete?", `Are you sure you wish to delete the command: ${command["name"]}?`, function() {
			const index = TCodeCommands.findIndex(x => x.name == command["name"]);
			closeAlertWindow();
			if(index > -1) {
				TCodeCommands.splice(index, 1);
				tr.remove();
				const rows = document.getElementsByName("tcodeCommandRow");
				if(!rows?.length) {
					addNoTCodeCommandsFoundRow();
				}
				checkTCodeCommandSetupFormDirty(true);
			} else {
				systemError(`There was an error. Command not found ${command["name"]}. Try refreshing the page.`)
			}
		});
	};
	tdDelete.appendChild(buttonDelete);
	tr.appendChild(tdDelete);
	return tr;
}
function addTCodeCommand() {
	removeNoTCodeCommandsFoundRow();
	const tbody = document.getElementById("tcodeCommandsSetupTableBody");
	const tr = getTCodeCommandTableRow();
	tbody.appendChild(tr);
	tr.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
	checkTCodeCommandSetupFormDirty(true);
}
function saveTCodeCommands() {
	const form = document.getElementById("tcodeCommandsSetupForm");
	if(!form.checkValidity())
	{
		userError("Cannot save, the form is invalid.");
		return;
	}
	postTCodeCommands(TCodeCommands);
}
function cancelTCodeCommands() {
	showAlertWindow("Reset?", `Are you sure you wish to reset all current tcode command changes?`, function() {
		getTCodeCommand();
		closeAlertWindow();
	});
}
function checkTCodeCommandSetupFormDirty(forceEnable = false) {
	const saveTCodeCommandsButton = document.getElementById("saveTCodeCommandsButton");
	const cancelTCodeCommandsButton = document.getElementById("cancelTCodeCommandsButton");
	if(forceEnable) {
		saveTCodeCommandsButton.disabled = false;
		cancelTCodeCommandsButton.disabled = false;
		return;
	}
	const form = document.getElementById("tcodeCommandsSetupForm");
	saveTCodeCommandsButton.disabled = !IsDirty(form);
	cancelTCodeCommandsButton.disabled = !IsDirty(form);
}

function markTCodeCommandFormClean() {
	const saveTCodeCommandsButton = document.getElementById("saveTCodeCommandsButton");
	saveTCodeCommandsButton.disabled = true;
	const cancelTCodeCommandsButton = document.getElementById("cancelTCodeCommandsButton");
	cancelTCodeCommandsButton.disabled = true;
}

function getServerSessions() {
	if(cookies.sessionID) {
		var xhr = new XMLHttpRequest();
		xhr.open('GET', "/activeSessions", true);
		xhr.responseType = 'json';
		xhr.onload = function (evnt) {
			var status = xhr.status;
			if (status === 200) {
				var activeSessions = xhr.response;
				var tBody = document.getElementById("sessionInfoBody");
				removeAllChildNodes(tBody);
				activeSessions.forEach(element => {
					var row = document.createElement("tr");
					row.id = element["id"];
					var cellSessionID = document.createElement("td");
					cellSessionID.innerText = element["id"];
					var cellCreate = document.createElement("td");
					cellCreate.innerText = element["lastAccessed"];
					var cellExpire = document.createElement("td");
					cellExpire.innerText = element["expire"];
					var cellCurrent = document.createElement("td");
					cellCurrent.innerText = element["current"] ? "*" : "";
					var cellDelete = document.createElement("td");
					var btnDelete = document.createElement("button");
					btnDelete.onclick = checkSession(element["id"]);
					btnDelete.innerText = "X"
					cellDelete.appendChild(btnDelete);
					row.appendChild(cellSessionID);
					row.appendChild(cellCreate);
					row.appendChild(cellExpire);
					row.appendChild(cellCurrent);
					row.appendChild(cellDelete);
					tBody.appendChild(row);
				});
			} else {
				parseHttpError("Error getting server sessions", xhr);
			}
		}.bind(this);
		xhr.onerror = function(evnt, retry) {
			parseHttpError("Error getting server sessions", xhr);
		};
		xhr.send();
	}
}

var checkSession = function (sessionID) {
	return function () {
		if(sessionID == cookies.sessionID)
			showAlertWindow("Logout?", "Are you sure you want to delete the current session? This will log you out.", function() {deleteSession(sessionID)});
		else
			deleteSession(sessionID);
	}
}

function deleteSession (sessionID) {
	var xhr = new XMLHttpRequest();
	xhr.open('POST', "/expireSession?sessionID="+sessionID, true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4) {
			var status = xhr.status;
			if (status == 200) {
				var sessionNode = document.getElementById(sessionID);
				document.getElementById("sessionInfoBody").removeChild(sessionNode);
				if(sessionID == cookies.sessionID) {
					delete_cookie("sessionID");
					logout();
				}
			} else {
				parseHttpError("Error deleting session", xhr);
			}
		}
	}
	xhr.onerror = function () {
		parseHttpError("Error deleting session", xhr);
	};
	xhr.send();
}

function startServerConnectionRetry() {
	stopServerConnectionRetry();
	setMediaLoading();
	setMediaLoadingStatus("Waiting for reconnect...");
	serverRetryTimeoutTries++;
	if (serverRetryTimeoutTries < 100) {
		serverRetryTimeout = setTimeout(() => {
			getServerSettings();
		}, 5000);
	} else {
		setMediaLoadingStatus("Timed out while looking for server. Please refresh the page when the server has started again.")
	}
}
function stopServerConnectionRetry() {
	if(serverRetryTimeout != undefined) {
		clearTimeout(serverRetryTimeout);
		serverRetryTimeout = undefined;
	}
}

function updateSettingsUI() {
	updateChannelsUI();
	setupConnectionsTab();

	document.getElementById("tabLocalTab").onclick();
}

function updateChannelsUI() {
	// //Dropdown
	// var profileNamesSelect = document.getElementById("profileNamesSelect");
	// removeAllChildNodes(profileNamesSelect);
	// remoteUserSettings["allChannelProfileNames"].forEach(x => {
	// 	var option = document.createElement("option");
	// 	option.value = x;
	// 	option.innerText = x;
	// 	profileNamesSelect.appendChild(option);
	// });
	// profileNamesSelect.value = remoteUserSettings.selectedChannelProfile;
	// Radios
	var profileNamesDiv = document.getElementById("profileNamesDiv");
	removeAllChildNodes(profileNamesDiv);
	remoteUserSettings["allChannelProfileNames"].forEach(x => {
		var radio = document.createElement("input");
		var label = document.createElement("label");
		radio.type = "radio";
		radio.id = x;
		radio.name = "motionProfileGroup";
		radio.value = x;
		radio.onclick = function() {
			setSelectedProfile(this.value);
		}
		if(x == remoteUserSettings.selectedChannelProfile) {
			radio.checked = true;
		}
		label.for = x;
		label.innerText = x;
		profileNamesDiv.appendChild(radio);
		profileNamesDiv.appendChild(label);
	});

	setupSliders();
	setupMotionModifiers();
}

function getServerLibrary() {
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/media", true);
	xhr.responseType = 'json';
	xhr.onload = function () {
		var status = xhr.status;
		if (status === 200) {
			mediaListGlobal = xhr.response;
			setThumbSize(thumbSizeGlobal, false);
			sort(sortByGlobal, false);
			mediaListDisplayed = getDisplayedMediaList(showGlobal, false);
			loadMedia(mediaListDisplayed);
			filter();
		} else {
			parseHttpError("Error getting media", xhr);
		}
	};
	xhr.onerror = function () {
		parseHttpError("Error getting media", xhr);
	};
	xhr.send();
}

function setInputConnectionStatus(deviceName, status, message) {
	// check &#x2714;
	// x &#x2718;
	// triangle ! &#x26A0;
	var statusImage = ""
	var statusColor = "";
	switch (status) {
		case ConnectionStatus.Connected:
			statusImage = "://images/icons/check-mark-black.png";
			statusColor = "chartreuse";
			break;
		case ConnectionStatus.Connecting:
			statusImage = "://images/icons/reload.svg";
			statusColor = "yellow";
			break;
		case ConnectionStatus.Disconnected:
			statusImage = "://images/icons/x.svg";
			statusColor = "crimson";
			break;
		case ConnectionStatus.Error:
			statusImage = "://images/icons/error-black.png";
			statusColor = "red";
			break;
	}
	var deoVRStatusImage = document.getElementById("deoVRStatus");
	var whirligigStatusImage = document.getElementById("whirligigStatus");
	var xtpWebStatusImage = document.getElementById("xtpWebStatus");
	var gamepadStatusImage = document.getElementById("gamepadStatus");
	if (deviceName != DeviceType.Gamepad) {
		deoVRStatusImage.src = "://images/icons/x.svg";
		deoVRStatusImage.style.backgroundColor = "crimson";
		deoVRStatusImage.title = "Disconnected";
		//deoVRStatusImage.alt = "Disconnected"
		whirligigStatusImage.src = "://images/icons/x.svg";
		whirligigStatusImage.style.backgroundColor = "crimson";
		whirligigStatusImage.title = "Disconnected";
		//whirligigStatusImage.alt = "Disconnected"
		xtpWebStatusImage.src = "://images/icons/x.svg";
		xtpWebStatusImage.style.backgroundColor = "crimson";
		xtpWebStatusImage.title = "Disconnected";
		//xtpWebStatusImage.alt = "Disconnected"
	}
	switch (deviceName) {
		case DeviceType.Deo:
			deoVRStatusImage.src = statusImage;
			deoVRStatusImage.style.backgroundColor = statusColor;
			deoVRStatusImage.title = message;
			//deoVRStatusImage.alt = message 
			break;
		case DeviceType.Whirligig:
			whirligigStatusImage.src = statusImage;
			whirligigStatusImage.style.backgroundColor = statusColor;
			whirligigStatusImage.title = message;
			//deoVRStatusImage.alt = message 
			break;
		case DeviceType.XTPWeb:
			xtpWebStatusImage.src = statusImage;
			xtpWebStatusImage.style.backgroundColor = statusColor;
			xtpWebStatusImage.title = message;
			//deoVRStatusImage.alt = message 
			break;
		case DeviceType.Gamepad:
			gamepadStatusImage.src = statusImage;
			gamepadStatusImage.style.backgroundColor = statusColor;
			gamepadStatusImage.title = message;
			//deoVRStatusImage.alt = message 
			break;

	}
}
function setDevicePauseStatus(isPaused)
{
	for (var i = 0; i < devicePauseStatusIconButtonNodes.length; i++) {
		var devicePauseStatusIconButtonNode = devicePauseStatusIconButtonNodes[i];
		var devicePauseStatusIconButtonImageNode = devicePauseStatusIconButtonImageNodes[i];
		devicePauseStatusIconButtonNode.title = "TCode device pause toggle.\nDevice status: ";
		
		if(isPaused)
		{
			devicePauseStatusIconButtonNode.title += "paused";
			devicePauseStatusIconButtonNode.classList.add("video-control--device-state-paused");
			devicePauseStatusIconButtonImageNode.setAttribute("src", "://images/icons/play.svg");
		}
		else
		{
			devicePauseStatusIconButtonNode.title += "not paused";
			devicePauseStatusIconButtonNode.classList.remove("video-control--device-state-paused");
			devicePauseStatusIconButtonImageNode.setAttribute("src", "://images/icons/pause.svg");
		}
	}
}

function setOutputConnectionStatus(deviceName, status, message) {
	for (var i = 0; i < deviceConnectionStatusRetryButtonNodes.length; i++) {
		var deviceConnectionStatusRetryButtonNode = deviceConnectionStatusRetryButtonNodes[i];
		var deviceConnectionStatusRetryButtonImageNode = deviceConnectionStatusRetryButtonImageNodes[i];
		deviceConnectionStatusRetryButtonNode.title = "TCode status: " + message;
		deviceConnectionStatusRetryButtonNode.style.cursor = "";
		deviceConnectionStatusRetryButtonNode.disabled = true;
		var tcodeDeviceSettingsLink = document.getElementById("tcodeDeviceSettingsLink");
		tcodeDeviceSettingsLink.hidden = true;
		outputConnectionStatus = status;
		switch (status) {
			case ConnectionStatus.Disconnected:
				deviceConnectionStatusRetryButtonNode.style.backgroundColor = "crimson";
				deviceConnectionStatusRetryButtonNode.style.cursor = "pointer";
				deviceConnectionStatusRetryButtonNode.disabled = false;
				deviceConnectionStatusRetryButtonImageNode.src = "://images/icons/x.svg";
				deviceConnectionStatusRetryButtonNode.title += ": Check your devices connection and click this to retry"
				break;
			case ConnectionStatus.Connecting:
				deviceConnectionStatusRetryButtonNode.style.backgroundColor = "yellow";
				deviceConnectionStatusRetryButtonImageNode.src = "://images/icons/reload.svg";
				break;
			case ConnectionStatus.Connected:
				outputDeviceConnected = true;
				deviceConnectionStatusRetryButtonNode.style.backgroundColor = "chartreuse";
				deviceConnectionStatusRetryButtonImageNode.src = "://images/icons/check-mark-black.png";
				if (remoteUserSettings.connection.output.selectedDevice == DeviceType.Network) {
					tcodeDeviceSettingsLink.href = "http://" + remoteUserSettings.connection.output.networkAddress;
					tcodeDeviceSettingsLink.hidden = false;
				}
				break;
			case ConnectionStatus.Error:
				deviceConnectionStatusRetryButtonNode.style.backgroundColor = "red";
				deviceConnectionStatusRetryButtonNode.style.cursor = "pointer";
				deviceConnectionStatusRetryButtonNode.disabled = false;
				deviceConnectionStatusRetryButtonImageNode.src = "://images/icons/error-black.png";
				deviceConnectionStatusRetryButtonNode.title += ": Check your devices connection and click this to retry"
				break;

		}
	}
	var statusImage = ""
	var statusColor = "";
	switch (status) {
		case ConnectionStatus.Connected:
			statusImage = "://images/icons/check-mark-black.png";
			statusColor = "chartreuse";
			break;
		case ConnectionStatus.Connecting:
			statusImage = "://images/icons/reload.svg";
			statusColor = "yellow";
			break;
		case ConnectionStatus.Disconnected:
			statusImage = "://images/icons/x.svg";
			statusColor = "crimson";
			break;
		case ConnectionStatus.Error:
			statusImage = "://images/icons/error-black.png";
			statusColor = "red";
			break;
	}
	var networkStatusImage = document.getElementById("networkStatus");
	var serialStatusImage = document.getElementById("serialStatus");
	networkStatusImage.src = "://images/icons/x.svg";
	networkStatusImage.style.backgroundColor = "crimson";
	networkStatusImage.title = "Disconnected";
	//networkStatusImage.alt = "Disconnected"
	serialStatusImage.src = "://images/icons/x.svg";
	serialStatusImage.style.backgroundColor = "crimson";
	serialStatusImage.title = "Disconnected";
	switch (deviceName) {
		case DeviceType.Network:
			networkStatusImage.src = statusImage;
			networkStatusImage.style.backgroundColor = statusColor;
			networkStatusImage.title = message;
			//networkStatusImage.alt = message 
			break;
		case DeviceType.Serial:
			serialStatusImage.src = statusImage;
			serialStatusImage.style.backgroundColor = statusColor;
			serialStatusImage.title = message;
			//serialStatusImage.alt = message 
			break;

	}
	//whirligigStatusImage.alt = "Disconnected"
}
/* function getDeviceConnectionStatus() {
	if(deviceConnectionStatusInterval)
		clearTimeout(deviceConnectionStatusInterval);
	var xhr = new XMLHttpRequest();
	xhr.open('GET', "/settings/deviceConnectionStatus", true);
	xhr.responseType = 'json';
	xhr.onload = function() {
	  var status = xhr.status;
	  if (status === 200) {
		var connectionStatusEvent = xhr.response;
		connectionStatus = connectionStatusEvent.status;
		setConnectionStatus(connectionStatus, connectionStatusEvent.message);
		pollDeviceConnectionStatus(30000);
		if(connectionStatus == ConnectionStatus.Connecting) {
			pollDeviceConnectionStatus(1000);
		}
	  } else {
		systemError("Http Error getting device connection status: "+ status);
		if(deviceConnectionStatusInterval)
			clearTimeout(deviceConnectionStatusInterval);
			setConnectionStatus(ConnectionStatus.Error, "Http Error getting device connection status: "+ status);
	  }
	};
	xhr.onerror = function() {
		var status = xhr.status;
		systemError("Error getting device connection status: "+ status);
		if(deviceConnectionStatusInterval)
			clearTimeout(deviceConnectionStatusInterval);
			setConnectionStatus(ConnectionStatus.Error, "Error getting device connection status: "+ status);
	};
	xhr.send();
} */

/* function pollDeviceConnectionStatus(pollInterval) {
	if(deviceConnectionStatusInterval) {
		clearTimeout(deviceConnectionStatusInterval);
		deviceConnectionStatusInterval = null;
	}
	deviceConnectionStatusInterval = setTimeout(function () {
		getDeviceConnectionStatus();
	}, pollInterval);
} */


function getMediaFunscripts(path, isMFS) {
	var channel = funscriptChannels[currentChannelIndex];
	var trackName = remoteUserSettings["availableChannels"][channel]["trackName"];
	var xhr = new XMLHttpRequest();
	var channelPath = trackName === "" ? trackName : "." + trackName;
	xhr.open('GET', path + channelPath + ".funscript", true);
	xhr.responseType = 'json';
	xhr.onload = function () {
		var status = xhr.status;
		if (status === 200) {
			loadedFunscripts.push({ "channel": channel, "atList": [] });
			var index = loadedFunscripts.length - 1;
			var items = xhr.response;
			for (var i = 0; i < items.actions.length; i++) {
				var item = items.actions[i];
				var at = item["at"];
				loadedFunscripts[index][at] = item["pos"];
				loadedFunscripts[index].atList.push(at);
			}
			currentChannelIndex++;
			if (currentChannelIndex < funscriptChannels.length) {
				getMediaFunscripts(path, isMFS);
			}
			else {
				currentChannelIndex = 0;
				videoNode.play();
				console.log("Funscripts load finish");
			}
		}
		else {
			parseHttpError("Error getting media funscripts", xhr);
		}
	};
	xhr.send();
}

function onSaveToXTPClick() {
	postServerSettings();
}
function postServerSettings() {
	setSaveState(null, true);
	var xhr = new XMLHttpRequest();
	xhr.open('POST', "/settings", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4) {
			var status = xhr.status;
			if (status !== 200)
				onSaveFail(xhr);
			else {
				onSaveSuccess();
				markXTPFormClean();
			}
		}
	}
	xhr.onerror = function () {
		onSaveFail(xhr);
	};
	xhr.send(JSON.stringify(remoteUserSettings));
}

function validateMetadata(metaData) {
	if(metaData.MFSScripts && metaData.MFSScripts.length > 100)
	{
		showAlertWindow("System error", `There is a possible issue with this items metadata.<br>
			Doing a metadata process by clicking one of the buttons below or<br>
			from 'Settings \> System \> Process metadata' should fix this issue<br>
			You can also click 'Update metadata' from this media items context menu.<br>
			Note: you may need to resave after the item has been updated.<br><br>
			<button style='margin-top:8px' onclick='closeAlertWindow();sendUpdateMetadata(\"${metaData.key}\");'>Process ONLY THIS items metadata</button>
			<button onclick='closeAlertWindow();startMetadataProcess();'>Start processing ALL metadata now</button>`
		);
	}
}

function postMediaItemMetaData(libraryItem) {
	validateMetadata(libraryItem.metaData);
	var xhr = new XMLHttpRequest();
	xhr.open('POST', "/mediaItemMetadata", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4) {
			var status = xhr.status;
			if (status !== 200)
				onSaveFail(xhr, metaDataSaveStateNode);
			else {
				onSaveSuccess(metaDataSaveStateNode);
				document.getElementById("saveMediaItemMetaDataButton").disabled = true;
			}
			updateMediaItemHeader(libraryItem);
		}
	}
	xhr.onerror = function () {
		onSaveFail(xhr, metaDataSaveStateNode);
		updateMediaItemHeader(libraryItem);
	};
	xhr.send(JSON.stringify(libraryItem.metaData));
}

function postTCodeCommands(commands) {
	var xhr = new XMLHttpRequest();
	xhr.open('POST', "/tcodeCommands", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4) {
			var status = xhr.status;
			if (status !== 200)
				onSaveFail(xhr, null, "Error saving tcode commands");
			else {
				onSaveSuccess();
				getTCodeCommand();
			}
		}
	}
	xhr.onerror = function () {
		onSaveFail(xhr, null, "Error saving tcode commands");
	};
	xhr.send(JSON.stringify(commands));
}

function postMediaState(mediaState) {
	if(!xtpConnected)
		return;
	var xhr = new XMLHttpRequest();
	xhr.open("POST", "/xtpweb", true);
	xhr.setRequestHeader('Content-Type', 'application/json');
	xhr.send(JSON.stringify(mediaState));
	xhr.oneload = function () {
		var status = xhr.status;
		if (status !== 200)
			parseHttpError("Error sending media state", xhr);
	};
	xhr.onerror = function () {
		parseHttpError("Error sending media state", xhr);
	};
}

function onSaveSuccess(node) {
	setSaveState(node, false);
}
function onSaveFail(xhr, node, message) {
	if(xhr)
		parseHttpError("Save fail", xhr);
	setSaveState(node, false, message);
}
function saveFail(message) {
	onSaveFail(null, null, message)
}

function onSettingsExported(message, path, success) {
	if(!success) {
		systemError("Failed to export settings: "+ message);
		return;
	}
	setSaveState(null, false);
	getExported();
}
function onSettingsImported(message, path, success) {
	if(!success) {
		systemError("Failed to import settings: "+ message);
		return;
	}
	refreshPageOnReconnect = true;
	setSaveState(null, false);
}
function clearMediaList() {
	var medialistNode = document.getElementById("mediaList");
	removeAllChildNodes(medialistNode);
	return medialistNode;
}
function loadMedia(mediaList) {
	var medialistNode = clearMediaList();

	var noMediaElement = document.getElementById("noMedia");
	if (!mediaList || mediaList.length == 0) {
		if(!mediaLoading) {
			noMediaElement.innerHTML = "No media found<br>Current filter: " + showGlobal;
			noMediaElement.hidden = false;
		}
		return;
	}
	noMediaElement.hidden = true;

	var createClickHandler = function (obj) {
		return function () {
			//loadVideo(obj); 
			playVideo(obj);
		}
	};

	var toggleFavorite = function (mediaItem, favSVG) {
		let favIndex = updateFavorite(mediaItem, favSVG);
		let isFav = favIndex > -1;
		if(isFav) {
			mediaItem.metaData.tags.splice(favIndex, 1);
		} else {
			mediaItem.metaData.tags.push("favorite");
		}
		postMediaItemMetaData(mediaItem);
	};

	var toggleContext = function (contextMenu, mediaItem) {
			contextMenu.classList.toggle("hidden");
			var thumbAtPosMenuItem = contextMenu.getElementsByClassName("setThumbAtCurrent")[0];
			var setMoneyShotAtCurrentMenuItem = contextMenu.getElementsByClassName("setMoneyShotAtCurrent")[0];
			var isSelectPlayingCurrently = playingmediaItem && playingmediaItem.id === mediaItem.id;
			if(isVideoShown() && isSelectPlayingCurrently) {
				thumbAtPosMenuItem.classList.remove("disabled");
				setMoneyShotAtCurrentMenuItem.classList.remove("disabled");
				setMoneyShotAtCurrentMenuItem.title = "Set moneyshot at current"
				thumbAtPosMenuItem.title = "Set thumb at current"
			} else {
				thumbAtPosMenuItem.classList.add("disabled");
				thumbAtPosMenuItem.title = "This is not the current playing video so it cannot be set at the current position."
				setMoneyShotAtCurrentMenuItem.classList.add("disabled");
				setMoneyShotAtCurrentMenuItem.title = "This is not the current playing video so it cannot be set at the current position."
			}

			var showAlternateScripts = contextMenu.getElementsByClassName("showAlternateScripts")[0];
			if(isSelectPlayingCurrently) {
				if(selectedMediaItemAltScriptCount > 0) {
					showAlternateScripts.style.color = "green";
					showAlternateScripts.classList.remove("disabled");
					showAlternateScripts.title = "Select alternate scripts if there are any."
				} else {
					showAlternateScripts.style.color = "grey";
					showAlternateScripts.classList.add("disabled");
					showAlternateScripts.title = "No alternate scripts for current media."
				}
			} else {
				showAlternateScripts.style.color = "grey";
				showAlternateScripts.classList.add("disabled");
				showAlternateScripts.title = "This is not the current playing video."
			}

			var regenerateThumbMenuItem = contextMenu.getElementsByClassName("regenerateThumb")[0];
			if(mediaItem.managedThumb && !mediaItem.thumb.includes(".lock."))
				regenerateThumbMenuItem.classList.remove("disabled");
			else {
				regenerateThumbMenuItem.classList.add("disabled");
				regenerateThumbMenuItem.title = "This thumb file is not modifiable because it is not managed by XTP."
			}
	};

	var closeContext = function (contextMenu) {
		return function () {
			contextMenu.classList.add("hidden");
		}
	};

	var mediaSettingsClick = function (mediaItem, contextMenu) {
		return function () {
			openMetaDataModal(mediaItem);
			contextMenu.classList.add("hidden");
		}
	};
	
	var regenThumbClick = function (mediaItem, contextMenu) {
		return function () {
			sendUpdateThumb(mediaItem);
			contextMenu.classList.add("hidden");
		}
	};
	var regenThumbCurrentPosClick = function (mediaItem, contextMenu) {
		return function () {
			sendUpdateThumbAtPos(mediaItem);
			contextMenu.classList.add("hidden");
		}
	};
	var setMoneyShotCurrentPosClick = function (mediaItem, contextMenu) {
		return function () {
			mediaItem["metaData"]["moneyShotMillis"] = Math.round(videoNode.currentTime * 1000).toString();
			postMediaItemMetaData(mediaItem);
			contextMenu.classList.add("hidden");
		}
	};
	var updateItemMetadata = function (mediaItem, contextMenu) {
		return function () {
			sendUpdateMetadata(mediaItem.metaData.key);
			contextMenu.classList.add("hidden");
		}
	}
	var showAlternateScripts = function (mediaItem, contextMenu) {
		return function () {
			openAlternateScriptsModal(mediaItem);
		}
	}

	var deleteMediaItemWrapper = function (mediaItem, contextMenu) {
		return function () {
			deleteMediaItem(mediaItem);
		}
	}

	var textHeight = 0
	var width = 0;
	var widthInt = 0;
	var height = 0;
	var fontSize = 0;
	for (var i = 0; i < mediaList.length; i++) {
		var obj = mediaList[i];

		if (!thumbSizeGlobal) {
			setThumbSize(obj.thumbSize, true);
			setThumbSize(obj.thumbSize, false);
		}
		if (!textHeight) {
			textHeight = (thumbSizeGlobal * 0.25);
			widthInt = thumbSizeGlobal + (thumbSizeGlobal * 0.15);
			width = widthInt+ "px";
			height = thumbSizeGlobal + textHeight + "px";
			fontSize = (textHeight * 0.35) + "px";
		}
		var divnode = document.createElement("div");
		divnode.id = obj.id
		divnode.classList.add("media-item");
		divnode.style.width = width;
		divnode.style.height = height;
		divnode.title = obj.tooltip;
		divnode.setAttribute("data-display-name", obj.displayName);

		var headerDiv = document.createElement("div");
		headerDiv.classList.add("media-item-header");
		var headerStart = document.createElement("div");
		headerStart.classList.add("media-item-header-start");
		var headerEnd = document.createElement("div");
		headerEnd.id = obj.id + "MediaItemHeaderInfo"
		headerEnd.classList.add("media-item-header-end");
		headerDiv.appendChild(headerStart);
		headerDiv.appendChild(headerEnd);
		var info = document.createElement("button");
		info.id = obj.id + "InfoButton";
		info.classList.add("media-context");
		info.style.width = widthInt * mediaItemHeaderMultiplier + "px";
		info.style.height = widthInt * mediaItemHeaderMultiplier + "px";
		var contextMenu = document.createElement("div"); 
		contextMenu.id = obj.id + "ContextMenu";
		info.onclick = toggleContext.bind(this, contextMenu, obj);
		info.dataset.title = "Media actions";
		// var icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		// icon.style.width = widthInt * 0.08 + "px";
		// icon.style.height = widthInt * 0.08 + "px";
		// //icon.classList.add("player-button-png");
		// var iconUse = document.createElementNS("http://www.w3.org/2000/svg", "use");
		// iconUse.setAttribute("href", "://images/icons/context-menu.svg");
		var icon = document.createElement("img");
		icon.src = "://images/icons/context-menu.svg";
		icon.style.width = widthInt * mediaItemHeaderIconMultiplier + "px";;
		icon.style.height = widthInt * mediaItemHeaderIconMultiplier + "px";
		//icon.appendChild(iconUse);
		info.appendChild(icon);
		headerStart.appendChild(info);
		contextMenu.classList.add("media-context-menu", "hidden");
		

		
		contextMenu.style.fontSize = fontSize;
		//contextMenu.style.width = widthInt * 0.85 + "px";

		var contextMenuItem = createContextMenuItem("Regenerate thumb", regenThumbClick(obj, contextMenu));
		contextMenuItem.classList.add("regenerateThumb", "disabled");
		contextMenu.appendChild(contextMenuItem);
		var contextMenuItem = createContextMenuItem("Set thumb at current", regenThumbCurrentPosClick(obj, contextMenu));
		contextMenuItem.classList.add("setThumbAtCurrent", "disabled");
		contextMenu.appendChild(contextMenuItem);
		var contextMenuItem = createContextMenuItem("Set moneyshot at current", setMoneyShotCurrentPosClick(obj, contextMenu));
		contextMenuItem.classList.add("setMoneyShotAtCurrent", "disabled");
		contextMenu.appendChild(contextMenuItem);
		var updateMetadataMenuItem = createContextMenuItem("Process metadata", updateItemMetadata(obj, contextMenu));
		contextMenu.appendChild(updateMetadataMenuItem);
		var contextMenuItem = createContextMenuItem("Properties", mediaSettingsClick(obj, contextMenu));
		contextMenu.appendChild(contextMenuItem);
		var contextMenuItem = createContextMenuItem("Alternate scripts", showAlternateScripts(obj, contextMenu));
		contextMenuItem.classList.add("showAlternateScripts", "disabled");
		contextMenu.appendChild(contextMenuItem);
		if(mediaManagementEnabled) {
			var contextMenuItem = createContextMenuItem("Delete...", deleteMediaItemWrapper(obj, contextMenu));
			contextMenu.appendChild(contextMenuItem);
		}
		var contextCancelMenuItem = createContextMenuItem("Cancel", closeContext(contextMenu));
		contextMenu.appendChild(contextCancelMenuItem);

		divnode.appendChild(contextMenu);
		divnode.appendChild(headerDiv);

		var anode = document.createElement("a");
		anode.className += "media-link"
		
		//anode.style.width = width;
		//anode.style.height = height;
		anode.onclick = createClickHandler(obj);


		var image = document.createElement("img");
		
		if(!disableLazyLoad) {
			if (obj.thumbFileExists)
				image.dataset.src = "/thumb/" + obj.relativeThumb;
			else
				image.dataset.src = "/thumb/" + (obj.thumbState === ThumbState.Unknown ? obj.thumbFileUnknown : obj.thumbState === ThumbState.Error ? obj.thumbFileError : obj.thumbFileLoading);
			image.classList.add("lazy");
		} else {
			if (obj.thumbFileExists)
				image.src = "/thumb/" + obj.relativeThumb;
			else 
				image.src = "/thumb/" + (obj.thumbState === ThumbState.Unknown ? obj.thumbFileUnknown : obj.thumbState === ThumbState.Error ? obj.thumbFileError : obj.thumbFileLoading);
			image.loading = "lazy"
		}
		image.classList.add("media-thumb-nail")
		image.style.width = thumbSizeGlobal + "px";
		image.style.height = thumbSizeGlobal - textHeight + "px";
		//image.onerror=onThumbLoadError(image, 1)
		var namenode = document.createElement("div");
		namenode.id = obj.id + "DisplayName";
		namenode.innerText = obj.displayName;
		namenode.className += "name"
		namenode.style.width = width;
		namenode.style.height = textHeight + "px";
		namenode.style.fontSize = fontSize;

		updateScriptStatus(obj, divnode, namenode);

		divnode.appendChild(anode);
		anode.appendChild(image);
		anode.appendChild(namenode);

		divnode.hidden = isFiltered(userFilterCriteria, divnode.innerText);
		medialistNode.appendChild(divnode);
		if (playingmediaItem && playingmediaItem.id === obj.id)
			setPlayingMediaItem(obj);

		if(obj.subtitle) {// Must be after divnode has been appended
			updateSubTitle(obj, divnode, contextMenu);
		}
		updateAlternate(obj, headerEnd);
		updateViewed(obj, headerEnd)

		// Keep at after tool bar end actions above for right alignment
		var faveButton = document.createElement("button");
		faveButton.id = obj.id + "InfoFavoriteButton";
		faveButton.classList.add("media-context");
		faveButton.style.width = widthInt * mediaItemHeaderMultiplier + "px";
		faveButton.style.height = widthInt * mediaItemHeaderMultiplier + "px";
		faveButton.dataset.title = "Tag favorite";
		var favSVG = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
		favSVG.id = obj.id + "InfoFavoriteIcon";
		var favIcon = document.createElementNS('http://www.w3.org/2000/svg', 'use');
		favSVG.appendChild(favIcon);
		favSVG.style.width = widthInt * mediaItemHeaderIconMultiplier + "px";;
		favSVG.style.height = widthInt * mediaItemHeaderIconMultiplier + "px";
		favIcon.setAttribute("href", "#heart");
		faveButton.onclick = toggleFavorite.bind(this, obj, favSVG);
		updateFavorite(obj, headerEnd, favSVG);
		faveButton.appendChild(favSVG);
		headerEnd.appendChild(faveButton);
	}
	if(!disableLazyLoad)
		setupLazyLoad();
}

function createMediaContextNode(parent, mediaItem) {
	// var regenThumbClick = function (mediaItem) {
	// 	return function () {
	// 		sendUpdateThumb(mediaItem)
	// 	}
	// };
	// var infoContainer = document.createElement("div");
	// infoContainer.id = "mediaContextContainer";
	// infoContainer.style.left = parent.style.right;
	// infoContainer.style.top = parent.style.bottom;
	// var contextMenu = document.createElement("div"); 
	// contextMenu.classList.add("media-context-menu");
	// var regenerateThumbContextItem = document.createElement("a");
	// regenerateThumbContextItem.classList.add("media-context-menu-item");
	// regenerateThumbContextItem.innerText = "Regenerate thumb";
	// regenerateThumbContextItem.onclick = regenThumbClick(mediaItem);
	// contextMenu.appendChild(regenerateThumbContextItem);
	// infoContainer.appendChild(contextMenu);
	// document.documentElement.appendChild(infoContainer);
}

function createContextMenuItem(innerText, onclick) {
	var contextMenuItem = document.createElement("div");
	contextMenuItem.classList.add("media-context-menu-item");
	contextMenuItem.innerText = innerText;
	contextMenuItem.onclick = onclick;
	return contextMenuItem;
}

function destroyMediaContextNode(event) {
	// if(event.target.classList.contains("media-context"))
	// 	return;
	// var node = document.getElementById("mediaContextContainer");
	// if(node)
	// 	document.documentElement.removeChild(node);
}

function setupLazyLoad() {
	var lazyImages = [].slice.call(document.querySelectorAll("img.lazy"));;
	if ("IntersectionObserver" in window && "IntersectionObserverEntry" in window && "intersectionRatio" in window.IntersectionObserverEntry.prototype) {
	  let lazyImageObserver = new IntersectionObserver(function(entries, observer) {
		entries.forEach(function(entry) {
		  if (entry.isIntersecting) {
			let lazyImage = entry.target;
			lazyImage.src = lazyImage.dataset.src;
			//lazyImage.srcset = lazyImage.dataset.srcset;
			lazyImage.classList.remove("lazy");
			lazyImageObserver.unobserve(lazyImage);
		  }
		});
	  });
  
	  lazyImages.forEach(function(lazyImage) {
		lazyImageObserver.observe(lazyImage);
	  });
	}
}

function updateItem(libraryItem, roles)
{
	var mediaNode;
	updateMediaItemHeader(libraryItem);
	if(roles.findIndex(x => x == Roles.DisplayRole) > -1) {
		mediaNode = updateScriptStatus(libraryItem);
	}
	if(roles.findIndex(x => x == Roles.DecorationRole) > -1) {
		mediaNode = updateSubTitle(libraryItem, mediaNode);
	} else {
		showChange(showGlobal);
		systemSuccess(`Item updated!`);
	}
	var index = mediaListGlobal.findIndex(x => x.id == libraryItem.id);
	if(index > -1) {
		mediaListGlobal[index] = JSON.parse(JSON.stringify(libraryItem));
		if(playingmediaItem && playingmediaItem.id == libraryItem.id) {
			playingmediaItem = mediaListGlobal[index];
		}
		if(selectedMediaItemForMetaData && selectedMediaItemForMetaData.id == libraryItem.id) {
			selectedMediaItemForMetaData = mediaListGlobal[index];
		}
	}
}
function addItem(libraryItem)
{
	mediaListGlobal.push(libraryItem);
	showChange(showGlobal);
}

function deleteItem(itemID) {
	const index = mediaListGlobal.findIndex(x => x.id == itemID);
	if(index > -1)
		mediaListGlobal.splice(index, 1);
	showChange(showGlobal);
}

function updateAlternate(libraryItem, mediaItemHeaderInfo) {
	if(!mediaItemHeaderInfo)
		mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
	if(!mediaItemHeaderInfo)
		return;
	var icon = document.getElementById(libraryItem.id+ "IconAlt")
	if(!icon) {
		const altScripts = filterAltScripts(libraryItem);
		icon = document.createElement("div");
		icon.id = libraryItem.id+ "IconAlt";
		icon.title = "Alternate script count"
		// icon.src = "://images/icons/cc.svg";
		widthInt = thumbSizeGlobal + (thumbSizeGlobal * mediaItemHeaderMultiplier);
		icon.style.width = widthInt * mediaItemHeaderIconMultiplier + "px";;
		icon.style.height = widthInt * mediaItemHeaderIconMultiplier + "px";
		icon.classList.add("media-item-info-icon");
		icon.classList.add("media-item-info-icon--margin");
		icon.style.color = "green";
		icon.innerText = altScripts.length;
		//icon.appendChild(iconUse);
		mediaItemHeaderInfo.appendChild(icon);
	}
	
	if(libraryItem.metaData.hasAlternate) {
		icon.classList.remove("hidden");
	} else {
		icon.classList.add("hidden");
	}
}
function updateMediaItemHeader(libraryItem, mediaItemHeaderInfo) {
	if(!mediaItemHeaderInfo)
		mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
	if(!mediaItemHeaderInfo)
		return;
	updateFavorite(libraryItem, mediaItemHeaderInfo);
	updateViewed(libraryItem, mediaItemHeaderInfo);
}

function updateFavorite(libraryItem, mediaItemHeaderInfo, svg) {
	if(!mediaItemHeaderInfo)
		mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
	if(!mediaItemHeaderInfo)
		return;
	if(!svg) {
		svg = document.getElementById(libraryItem.id + "InfoFavoriteIcon");
	}
	const favIndex = libraryItem.metaData.tags && libraryItem["metaData"].tags.findIndex(x => x === "favorite");
	svg.style.fill = favIndex > -1 ? "crimson" : "transparent";
	svg.style.stroke = favIndex > -1 ? "crimson" : "grey";
	return favIndex;
}

function updateViewed(libraryItem, mediaItemHeaderInfo) {
	if(!mediaItemHeaderInfo)
		mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
	if(!mediaItemHeaderInfo)
		return;
	var svg = document.getElementById(libraryItem.id+ "IconViewedSVG")
	if(!svg) {
		// icon = document.createElement("div");
		var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
		svg.id = libraryItem.id + "IconViewedSVG";
		var use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
		use.setAttribute("href", "#check");
		svg.appendChild(use);
		svg.style.width = widthInt * mediaItemHeaderIconMultiplier + "px";;
		svg.style.height = widthInt * mediaItemHeaderIconMultiplier + "px";
		svg.id = libraryItem.id+ "IconViewed";
		svg.title = "Viewed"
		svg.classList.add("media-item-info-icon--margin");
		// svg.style.fill = "green";
		// svg.style.stroke = "green";
		// icon.appendChild(svg);
		if(!mediaItemHeaderInfo)
			mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
		mediaItemHeaderInfo.appendChild(svg);
	}
	const isViewed = libraryItem.metaData.tags && libraryItem.metaData.tags.findIndex(x => x == "viewed") > -1;
	if(isViewed) {
		svg.classList.remove("hidden");
	} else {
		svg.classList.add("hidden");
	}
}

function updateSubTitle(libraryItem, mediaNode, contextMenu) {
	if(!mediaNode)
		mediaNode = document.getElementById(libraryItem.id);
	if (!mediaNode)
		return undefined;
	if(!contextMenu)
		contextMenu = document.getElementById(libraryItem.id+"ContextMenu");
	if (!contextMenu)
		return mediaNode;

	var index = mediaListGlobal.findIndex(x => x.id === libraryItem.id);

	// var contextButton = document.getElementById(libraryItem.id + "InfoButton");
	var mediaItemHeaderInfo = document.getElementById(libraryItem.id + "MediaItemHeaderInfo");
	
	var icon = document.getElementById(libraryItem.id+ "ccIconImg")
	if(!icon) {
		icon = document.createElement("img");
		icon.id = libraryItem.id+ "ccIconImg";
		icon.title = "This item has subtitles available"
		icon.src = "://images/icons/cc.svg";
		widthInt = thumbSizeGlobal + (thumbSizeGlobal * mediaItemHeaderMultiplier);
		icon.style.width = widthInt * mediaItemHeaderIconMultiplier + "px";;
		icon.style.height = widthInt * mediaItemHeaderIconMultiplier + "px";
		icon.classList.add("media-item-info-icon");
		icon.classList.add("media-item-info-icon--margin");
		//icon.appendChild(iconUse);
		mediaItemHeaderInfo.appendChild(icon);
	}
	if(libraryItem.subtitle) {
		icon.classList.remove("hidden");
	} else {
		icon.classList.add("hidden");
	}

	var contextMenuItems = contextMenu.getElementsByClassName("downloadSubtitle");
	if(contextMenuItems.length)
		contextMenu.removeChild(contextMenuItems[0]);
	
	if(libraryItem.subtitle) {
		var subtitle_path =  "/media" + libraryItem.subtitleRelative;
		const ext = libraryItem.subtitleRelative.substring(libraryItem.subtitleRelative.lastIndexOf("."), libraryItem.subtitleRelative.length);
		const link = document.createElement("a");
		link.href = subtitle_path;
		link.setAttribute('download', libraryItem.displayName + ext);
		link.innerText = "Download subtitle";
		//link.onclick = contextMenu.classList.add("hidden");
		var contextSubtitleMenuItem = createContextMenuItem("", undefined);
		contextSubtitleMenuItem.classList.add("downloadSubtitle");
		contextSubtitleMenuItem.appendChild(link);
		contextMenu.insertBefore(contextSubtitleMenuItem, contextMenu.firstChild);
	}

	mediaListGlobal[index].subtitle = libraryItem.subtitle;
	mediaListGlobal[index].subtitleRelative = libraryItem.subtitleRelative;
	return mediaNode;
}

function updateScriptStatus(libraryItem, mediaNode, displayNameNode) {
	if(!mediaNode)
		mediaNode = document.getElementById(libraryItem.id);
	if (!mediaNode)
		return undefined;
	if(!displayNameNode)
		displayNameNode = document.getElementById(libraryItem.id + "DisplayName");
	if(!displayNameNode)
		return undefined;
	displayNameNode.innerText = libraryItem.displayName;
	if(libraryItem.metaData.isSFMA) {
		mediaNode.classList.add("media-item-sfma");
	} else if (libraryItem.isMFS && libraryItem.hasScript) {
		mediaNode.classList.add("media-item-mfs");
	} else if(libraryItem.isMFS && !libraryItem.hasScript) {
		mediaNode.classList.remove("media-item-mfs");
		mediaNode.classList.add("media-item-mfs-noscript");
	} else if(libraryItem.metaData.hasAlternate && !libraryItem.hasScript) {
		mediaNode.classList.add("media-item-alt-noscript");
	} else if (!libraryItem.hasScript) {
		mediaNode.classList.add("media-item-noscript");
	} else {
		mediaNode.classList.remove("media-item-noscript");
	}
	var index = mediaListGlobal.findIndex(x => x.id === libraryItem.id);
	mediaListGlobal[index].displayName = libraryItem.displayName;
	mediaListGlobal[index].isMFS = libraryItem.isMFS;
	mediaListGlobal[index].hasScript = libraryItem.hasScript;
	return mediaNode;
}

function onThumbLoadError(imageElement, tries) {
	imageElement.onerror = null;
	if (tries < 3) {
		imageElement.src = '://images/icons/loading.png';
		imageElement.onerror = onThumbLoadError(imageElement, 2);
	} else {
		imageElement.src = '://images/icons/error.png';
	}
}

function removeAllChildNodes(parent) {
	while (parent.firstChild) {
		parent.removeChild(parent.firstChild);
	}
}

function sort(value, userClick) {
	if (!value)
		value = "nameAsc";
	var randomButton = document.getElementById("randomizeButton");
	if(random !== "random" && !randomButton.classList.contains("hidden"))
		randomButton.classList.add("hidden")
	switch (value) {
		case "dateDesc":
			mediaListGlobal.sort(function (a, b) {
				return new Date(b.modifiedDate) - new Date(a.modifiedDate);
			});
			break;
		case "dateAsc":
			mediaListGlobal.sort(function (a, b) {
				return new Date(a.modifiedDate) - new Date(b.modifiedDate);
			});
			break;
		case "addedDesc":
			mediaListGlobal.sort(function (a, b) {
				return new Date(b.metaData.dateAdded) - new Date(a.metaData.dateAdded);
			});
			break;
		case "addedAsc":
			mediaListGlobal.sort(function (a, b) {
				return new Date(a.metaData.dateAdded) - new Date(b.metaData.dateAdded);
			});
			break;
		case "nameAsc":
			mediaListGlobal.sort(function (a, b) {
				var nameA = a.displayName.toUpperCase(); // ignore upper and lowercase
				var nameB = b.displayName.toUpperCase(); // ignore upper and lowercase
				if (nameA < nameB) {
					return -1;
				}
				if (nameA > nameB) {
					return 1;
				}
			});
			break;
		case "nameDesc":
			mediaListGlobal.sort(function (a, b) {
				var nameA = a.displayName.toUpperCase(); // ignore upper and lowercase
				var nameB = b.displayName.toUpperCase(); // ignore upper and lowercase
				if (nameB < nameA) {
					return -1;
				}
				if (nameB > nameA) {
					return 1;
				}
			});
			break;
		case "random":
			fy(mediaListGlobal)
			randomButton.classList.remove("hidden")
		break;
	}
	if (!userClick) {
		//document.getElementById("sortBy").value = value;
		if (value) {
			document.getElementById(value.toString()).checked = true;
		}
	}
	else {
		window.localStorage.setItem("sortBy", JSON.stringify(value));
		sortByGlobal = value;
	}
	return mediaListGlobal;
}

//https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array
function fy(a,b,c,d){//array,placeholder,placeholder,placeholder
	c=a.length;while(c)b=Math.random()*c--|0,d=a[c],a[c]=a[b],a[b]=d
}

function getDisplayedMediaList(showValue, userClick) {
	let filteredMediaScoped = [];
	//let mediaListGlobalCopy = JSON.parse(JSON.stringify(mediaListGlobal));
	switch (showValue) {
		case "All":
			filteredMediaScoped = JSON.parse(JSON.stringify(mediaListGlobal));
			break;
		case "3DOnly":
			filteredMediaScoped = mediaListGlobal.filter(x => x.type === MediaType.VR || x.metaData.tags.includes("vr"));
			break;
		case "2DAndAudioOnly":
			filteredMediaScoped = mediaListGlobal.filter(x => x.type === MediaType.Audio || x.type === MediaType.Video || x.metaData.tags.includes("2d") || x.metaData.tags.includes("audio"));
			break;
	}
	
	if(userClick != undefined) {
		if (!userClick) {
			document.getElementById(showValue.toString()).checked = true;
		}
	}
	return filteredMediaScoped
}

function clearFilterinput() {
	filterInput.value = "";
	filter();
}

function filter() {
	const currentCriteria = filterInput.value;
	userFilterCriteria = currentCriteria;
	filterInput.enabled = false;
	var mediaItems = document.getElementsByClassName("media-item");
	for (var item of mediaItems) {
		const libraryItem = mediaListDisplayed.find(x => x.id === item.id);
		const displayName = item.getAttribute("data-display-name");
		item.hidden = isFiltered(userFilterCriteria, displayName) || isTagFiltered(userTagFilterCriteria, libraryItem.metaData.tags);
	};
	filterInput.enabled = true;
}

function debounceFilter() {
	if (filterDebounce) 
		clearTimeout(filterDebounce);
	filterDebounce = setTimeout(function () {
		filter();
		filterDebounce = undefined;
	}, 500);
}

function isFiltered(criteria, textToSearch) {
	if (!criteria || criteria.trim().length == 0)
		return false;
	else
		return !textToSearch.trim().toUpperCase().includes(criteria.trim().toUpperCase());
}

var onFilterByTagClicked = function (tagCheckbox) {
	return function () {
		if(tagCheckbox) {
			if(tagCheckbox.checked)
				userTagFilterCriteria.push(tagCheckbox.value);
			else {
				var index = userTagFilterCriteria.findIndex(x => x == tagCheckbox.value);
				if(index > -1)
					userTagFilterCriteria.splice(index, 1);
			}
			filterByTag(userTagFilterCriteria);
		}
	}
};

function filterByTag(filterCriteria) {
	userTagFilterCriteria = filterCriteria;
	var tagsFilterOptions = document.getElementsByName(tagCheckboxesName);
	tagsFilterOptions.forEach(x => x.enabled = false);
	var mediaItems = document.getElementsByClassName("media-item");
	var orNode = document.getElementById("tagFilterORChk");
	for (var item of mediaItems) {
		const libraryItem = mediaListDisplayed.find(x => x.id === item.id);

		item.hidden = isTagFiltered(userTagFilterCriteria, libraryItem.metaData.tags, orNode.checked) || isFiltered(userFilterCriteria, item.textContent);
	};
	tagsFilterOptions.forEach(x => x.enabled = true);
}

function isTagFiltered(selectedTags, mediaTags, orMode) {
	if (!selectedTags || !selectedTags.length || !mediaTags || !mediaTags.length)
		return false;
	else {
		for(let i=0; i<selectedTags.length; i++) {
			if(orMode) {
				if (mediaTags.includes(selectedTags[i]))
					return false;
			} else if(!mediaTags.includes(selectedTags[i]))
				return true;
		}
	}
	return orMode;
}
/* 
function onClickUseDeoWebCheckbox(checkbox)
{
	toggleUseDeo(checkbox.checked, true);
}

function toggleUseDeo(value, userClicked)
{
	if(userClicked) {
		useDeoWeb = value;
		window.localStorage.setItem("useDeoWeb", JSON.stringify(useDeoWeb));
	}
	else
		document.getElementById("useDeoWebCheckbox").checked = value;
	if(!useDeoWeb)
	{
		deoVideoNode.style.display = "none";
		thumbsContainerNode.style.maxHeight = "";
	} else {
		deoVideoNode.style.display = "block";
		onResizeDeo();
	}
}

function loadVideo(obj) {
	if(useDeoWeb) {
		deoVideoNode.setAttribute("format", x.type === MediaType.VR ? "LR" : "mono");
		deoSourceNode.setAttribute("src", "/video/" + obj.relativePath);
		deoVideoNode.setAttribute("title", obj.name);
		deoVideoNode.setAttribute("cover-image", "/thumb/" + obj.relativeThumb);
		
		if(!DEO.isStarted(deoVideoNode))
			DEO.setVolume(deoVideoNode, 0.3);
		DEO.play(deoVideoNode);
	}
} 
*/
function onClickLazyLoadCheckbox(checkbox) {
	toggleLazyLoad(checkbox.checked, true);
}
function toggleLazyLoad(value, userClicked) {
	if (userClicked) {
		externalStreaming = value;
		window.localStorage.setItem("disableLazyLoad", JSON.stringify(value));
	}
	else
		document.getElementById("disableLazyLoadCheckbox").checked = value;
	if (value) {
		stopVideo();
	}
}

function onClickExternalStreamingCheckbox(checkbox) {
	toggleExternalStreaming(checkbox.checked, true);
}
function toggleExternalStreaming(value, userClicked) {
	if (userClicked) {
		externalStreaming = value;
		window.localStorage.setItem("externalStreaming", JSON.stringify(value));
	}
	else
		document.getElementById("externalStreamingCheckbox").checked = value;
	if (value) {
		stopVideo();
	}
	if(value)
		document.getElementById("externalPlayerHelp").classList.remove("hidden");
	else
		document.getElementById("externalPlayerHelp").classList.add("hidden");
}
function setupTextToSpeech() {
	if (typeof speechSynthesis === 'undefined') {
		speechNotInbrowser = true;
		disableTextToSpeech();
		return;
	}

	if (speechSynthesis.onvoiceschanged !== undefined) {
		speechSynthesis.onvoiceschanged = setupVoices;
	} else {
		setTimeout(function () {
			setupVoices();
		}, 1000);
	}

	selectedVoiceIndex = JSON.parse(window.localStorage.getItem("selectedVoiceIndex"));
	if (selectedVoiceIndex === null) {
		selectedVoiceIndex = 0;
		window.localStorage.setItem("selectedVoiceIndex", JSON.stringify(selectedVoiceIndex));
	}
	enableTextToSpeech = JSON.parse(window.localStorage.getItem("enableTextToSpeech"));
	if (enableTextToSpeech === null) {
		enableTextToSpeech = true;
		window.localStorage.setItem("enableTextToSpeech", JSON.stringify(enableTextToSpeech));
	}
	toggleEnableTextToSpeech(enableTextToSpeech, false);
	speechPitch = JSON.parse(window.localStorage.getItem("speechPitch"));
	if (speechPitch === null) {
		speechPitch = 1;
		window.localStorage.setItem("speechPitch", JSON.stringify(speechPitch));
	}
	toggleSpeechPitchChange(speechPitch, false);
	speechRate = JSON.parse(window.localStorage.getItem("speechRate"));
	if (speechRate === null) {
		speechRate = 1;
		window.localStorage.setItem("speechRate", JSON.stringify(speechRate));
	}
	toggleSpeechRateChange / (speechRate, false);
	speechVolume = JSON.parse(window.localStorage.getItem("speechVolume"));
	if (speechVolume === null) {
		speechVolume = 0.5;
		window.localStorage.setItem("speechVolume", JSON.stringify(speechVolume));
	}
	toggleSpeechVolumeChange(speechVolume, false);
}

function setupVoices() {
	systemVoices = speechSynthesis.getVoices();
	var voiceSelect = document.getElementById("voiceSelect");
	for (var i = 0; i < systemVoices.length; i++) {
		var option = document.createElement('option');
		option.textContent = systemVoices[i].name + ' (' + systemVoices[i].lang + ')';
		option.value = i;

		if (systemVoices[i].default) {
			option.textContent += ' — DEFAULT';
		}

		option.setAttribute('data-lang', systemVoices[i].lang);
		option.setAttribute('data-name', systemVoices[i].name);
		voiceSelect.appendChild(option);
	}
	voiceSelect.value = selectedVoiceIndex;
}

function onVoiceSelect(index) {
	selectedVoiceIndex = index;
	window.localStorage.setItem("selectedVoiceIndex", JSON.stringify(selectedVoiceIndex));
	onTextToSpeech("Hello I am " + systemVoices[selectedVoiceIndex].name);
}
function onTextToSpeech(message) {
	if (!message || !enableTextToSpeech || typeof speechSynthesis === 'undefined') {
		return;
	}
	if (systemVoices && systemVoices.length > 0) {
		var msg = new SpeechSynthesisUtterance();
		msg.voice = systemVoices[selectedVoiceIndex];
		msg.volume = speechVolume; // From 0 to 1
		msg.rate = speechRate; // From 0.1 to 10
		msg.pitch = speechPitch; // From 0 to 2
		//msg.lang = 'en';
		msg.text = message;
		window.speechSynthesis.speak(msg);
	}
}
function onEnableTextToSpeechClick(checkbox) {
	toggleEnableTextToSpeech(checkbox.checked, true);
}
function toggleEnableTextToSpeech(value, userClicked) {
	if (userClicked) {
		enableTextToSpeech = value;
		window.localStorage.setItem("enableTextToSpeech", JSON.stringify(value));
		if (value)
			onTextToSpeech("Voice enabled");
	}
	else
		document.getElementById("enableTextToSpeech").checked = value;

	document.getElementsByName("voiceFormElement").forEach(x => {
		x.style.display = value ? "grid" : "none"
	});
}
function onSpeechPitchChange(value) {
	toggleSpeechPitchChange(value, true);
}
function toggleSpeechPitchChange(value, userClicked) {
	if (userClicked) {
		speechPitch = value;
		window.localStorage.setItem("speechPitch", JSON.stringify(value));
		onTextToSpeech("Pitch changed to " + value);
	}
	else
		document.getElementById("speechPitch").value = value;
}
function onSpeechRateChange(value) {
	toggleSpeechRateChange(value, true);
}
function toggleSpeechRateChange(value, userClicked) {
	if (userClicked) {
		speechRate = value;
		window.localStorage.setItem("speechRate", JSON.stringify(value));
		onTextToSpeech("Rate changed to " + value);
	}
	else
		document.getElementById("speechRate").value = value;
}
function onSpeechVolumeChange(value) {
	toggleSpeechVolumeChange(value, true);
}
function toggleSpeechVolumeChange(value, userClicked) {
	if (userClicked) {
		speechVolume = value;
		window.localStorage.setItem("speechVolume", JSON.stringify(value));
		onTextToSpeech("Volume changed to " + value);
	}
	else
		document.getElementById("speechVolume").value = value;
}
function disableTextToSpeech(message) {
	var textToSpeechUnavailable = document.getElementById("textToSpeechUnavailable");
	textToSpeechUnavailable.hidden = false;
	if (message) {
		textToSpeechUnavailable.innerText = message;
	}
	var enableTTSCheckbox = document.getElementById("enableTextToSpeech");
	enableTTSCheckbox.title = "Text to speech is not available in your browser."
	enableTTSCheckbox.enabled = false;
	enableTTSCheckbox.checked = false;
	toggleEnableTextToSpeech(false, true);
}

function toggleShufflePlay() {
	if(!mediaListDisplayed.length)
		return;
	shufflePlayMode = !shufflePlayMode;
	if(shufflePlayMode) {
		document.getElementById("shuffleButton").classList.add("icon-button-down");
		showVideo();
		playVideo(getNextShuffleMediaItem());
	} else {
		shufflePlayModePlayedIndexed = {};
		document.getElementById("shuffleButton").classList.remove("icon-button-down");
	}
}

function getNextShuffleMediaItem() {
	var currentDisplayedMedia = getCurrentDisplayedMediaNodes();
	if(!currentDisplayedMedia || !currentDisplayedMedia.length) {
		return;
	}
	if(Object.keys(shufflePlayModePlayedIndexed).length === currentDisplayedMedia.length) {
		shufflePlayModePlayedIndexed = {};
	}
	// Find a media item that hasnt been played.
	var randomIndex;
	var id;
	do {
		randomIndex = Math.floor(Math.random() * (currentDisplayedMedia.length - 1));
		id = currentDisplayedMedia[randomIndex].id;
	} while(shufflePlayModePlayedIndexed[id]);

	document.getElementById(id).scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
	shufflePlayModePlayedIndexed[id] = true;
	return currentDisplayedMedia[randomIndex];
}
function playVideo(obj) {
	stopTimeSync();
	if (playingmediaItem) {
		if (playingmediaItem.id === obj.id)
			return;
		clearPlayingMediaItem();
		sendStopMedia();
		sendMediaState();
	}
	const index = mediaListGlobal.findIndex(x => x.id==obj.id);
	if(index == -1) {
		showAlertWindow("Error", "Unknown media Item. If this is an item outside the slected media libraries, try refreshing the page. If that doesnt work. Im sorry.");
		return;
	}
	const selectedMediaItem = mediaListGlobal[index];
	if(selectedMediaItem && selectedMediaItem.type == MediaType.ExternalType) {
		showAlertWindow("Error", "Cannot play external media items from this interface.<br>You can only modify media metadata.<br>Start the media item from the original location.");
		return;
	}
	setPlayingMediaItem(selectedMediaItem);
	if(obj["subtitle"]) {
		if(!externalStreaming) {
			if(obj["subtitle"].endsWith("vtt")) { // Only vtt is supported by html video element
				const tracks = videoNode.querySelectorAll("track");
				let track;
				if(!tracks.length) {
					track = document.createElement("track");
					track.default = true;
					videoNode.appendChild(track);
				} else {
					track = tracks[0];
				}
				track.src = "/media" + obj.subtitleRelative;
			} else {
				var tracks = videoNode.querySelectorAll('track')
				for (var i = 0; i < tracks.length; i++) {
					tracks[i].src = undefined;
				}
			}
		}
	} else {
		var tracks = videoNode.querySelectorAll('track')
		for (var i = 0; i < tracks.length; i++) {
			tracks[i].src = undefined;
		}
	}
	if (externalStreaming) {
		var file_path =  "/media" + obj.relativePath;// + "?sessionID="+cookies.sessionID;
		window.open(file_path);
		return;
	}
	if(!isVideoShown())
		showVideo();
	dataLoading();
	resetPlayRate();
	setupVideoSource("/media" + obj.relativePath);
	videoNode.setAttribute("title", obj.name);
	videoMediaName.innerText = obj.name;
	videoNode.setAttribute("poster", "/thumb/" + obj.relativeThumb);
	videoNode.load();
	// loadedFunscripts = [];
	// if(playingmediaItem.hasScript)
	// 	loadMediaFunscript(playingmediaItem.scriptNoExtensionRelativePath, playingmediaItem.isMFS);
	// else
	//videoNode.play();
}

function stopVideoClick() {
	stopVideo();
}
function stopVideo() {
	sendStopMedia();
	hideVideo();
	videoNode.pause();
	removeVideoSource();
	videoNode.removeAttribute("title");
	videoNode.removeAttribute("poster");
	videoMediaName.innerText = "";
	videoNode.load();
	if (playingmediaItem) {
		playingmediaItem.playing = false;
		playingmediaItem.stopped = true;
		sendMediaState();
		clearPlayingMediaItem();// Clear after sending so the correct state is applied.
	}
}

function skipVideoTo(timeInMSecs) {
	if(videoNode && playingmediaItem) {
		videoNode.currentTime = timeInMSecs;
	}
}

function onSkipToMoneyShotClick() {
	onSkipToMoneyShot();
}

function onSkipToMoneyShot() {
	if(playingmediaItem) {
		var moneyShotSecs = playingmediaItem.metaData.moneyShotSecs;
		if(moneyShotSecs < 1) {
			moneyShotSecs = videoNode.duration - (videoNode.duration * 0.1);
		}
		skipVideoTo(moneyShotSecs);
	}
}

function onToggleFilterInput(searchButton) {
	filterInputContainer.classList.toggle('hidden');
	searchButton.classList.toggle('icon-button-down');
}

function onToggleTagInput(tagButton) {
	var tagFilterOptions = document.getElementById('tagFilterOptions');
	tagFilterOptions.classList.toggle('hidden');
	tagButton.classList.toggle('icon-button-down');
}

function onToggleTCodeActionsMain(button) {
	var node = document.getElementById('tcodeActionsMain');
	node.classList.toggle('hidden');
	button.classList.toggle('icon-button-down');
}

function setupAlternateScripts(mediaItem) {
	var altScripts = mediaItem["metaData"]["scripts"];
	if(!altScripts || !altScripts.length) {
		userError("No scripts found in metadata. Try updating the metadata for the media item.")
		return;
	}
	var altScriptsButton = document.getElementById("alternate-scripts-button");
	altScriptsButton.disabled = true;
	var altScriptsGroup = document.getElementById("altScriptsGroup");
	removeAllChildNodes(altScriptsGroup);
	selectedMediaItemAltScriptCount = 0;
	altScripts.forEach(x => {
		if((x.containerType == ScriptContainerType.MFS || x.containerType == ScriptContainerType.ZIP) && x.type == ScriptType.MAIN)
		{
			return;
		}
        if(x.type != ScriptType.MAIN) // Dont count the "Default" main script
		selectedMediaItemAltScriptCount++;
		var div = document.createElement("div");
		var label = document.createElement("label");
		var radio = document.createElement("input");
		radio.type = "radio";
		radio.name = "altScriptsGroup";
		radio.value = x;
		label.textContent = getScriptInfoName(x);
		radio.id = getScriptInfoID(x);
		label.setAttribute("for", radio.id);
		if(!selectedMediaItemAltScript && x.name == "Default" || selectedMediaItemAltScript && selectedMediaItemAltScript.name == x.name) {
			radio.checked = true;
		}
		radio.onclick = function (x) {
			sendSwapScript(x);
			selectedMediaItemAltScript = x.name == "Default" ? null : x;
		}.bind(this, x);
		div.appendChild(radio);
		div.appendChild(label);
		altScriptsGroup.appendChild(div);
	});
	altScriptsButton.disabled = selectedMediaItemAltScriptCount <= 0;
	altScriptsButton.innerText = selectedMediaItemAltScriptCount;
	altScriptsButton.style.color = selectedMediaItemAltScriptCount <= 0 ? "grey" : "green";
}

function filterAltScripts(mediaItem) {
	let altScripts = [];
	var scripts = mediaItem["metaData"]["scripts"];
	if(!scripts || !scripts.length) {
		return altScripts;
	}
	
	scripts.forEach(x => {
		if((x.containerType == ScriptContainerType.MFS || x.containerType == ScriptContainerType.ZIP) && x.type == ScriptType.MAIN)
		{
			return;
		}
        if(x.type != ScriptType.MAIN) // Dont count the "Default" main script// TODO is this needed?
			altScripts.push(x);
	});
	return altScripts;
}

function getScriptInfoName(scriptInfo) {
	return scriptInfo.name + (scriptInfo.containerTypeName.length ? " " + scriptInfo.containerTypeName : "");
}
function getScriptInfoID(scriptInfo) {
	return getScriptInfoName(scriptInfo).replace(/^[0-9]+[\w\-\:\.]*$/, "");
}

function setPlayingMediaItem(obj) {
	playingmediaItem = obj;
	setupAlternateScripts(playingmediaItem);
	sendPlayMedia(obj);
	playingmediaItemNode = document.getElementById(obj.id);
	playingmediaItemNode.classList.add("media-item-playing");
}

function clearPlayingMediaItem() {
	playingmediaItemNode.classList.remove("media-item-playing");
	playingmediaItem = null;
	playingmediaItemNode = null;
}

function playNextVideoClick() {
	playNextVideo();
}

function playNextVideo() {
	if(mediaListDisplayed.length == 0)
		return;
	if(shufflePlayMode) {
		playVideo(getNextShuffleMediaItem())
	} else {
		var currentDisplayedMedia = getCurrentDisplayedMediaNodes();
		if(!currentDisplayedMedia || !currentDisplayedMedia.length) {
			return;
		}
		if(playingmediaItem) {
			var playingIndex = currentDisplayedMedia.findIndex(x => x.id === playingmediaItem.id);
			playingIndex++;
		} else {
			playingIndex = 0;
		}
		if (playingIndex < currentDisplayedMedia.length)
			playVideo(currentDisplayedMedia[playingIndex]);
		else
			playVideo(currentDisplayedMedia[0]);
	}
}
function playPreviousVideoClick() {
	playPreviousVideo();
}
function playPreviousVideo() {
	if(mediaListDisplayed.length == 0)
		return;
	var currentDisplayedMedia = getCurrentDisplayedMediaNodes();
	if(!currentDisplayedMedia || !currentDisplayedMedia.length) {
		return;
	}
	if(playingmediaItem) {
		var playingIndex = currentDisplayedMedia.findIndex(x => x.id === playingmediaItem.id);
		playingIndex--;
	} else {
		playingIndex = -1;
	}
	if (playingIndex < 0)
		playVideo(currentDisplayedMedia[currentDisplayedMedia.length - 1]);
	else
		playVideo(currentDisplayedMedia[playingIndex]);
}
function setThumbSize(value, userClick) {
	if (!userClick) {
		if (value) {
			document.getElementById(value.toString()).checked = true;
			//document.getElementById("thumbSize").value = value.toString();
		}
	} else {
		window.localStorage.setItem("thumbSize", parseInt(value, 10));
		thumbSizeGlobal = parseInt(value, 10);
	}
}

// function startFunscriptSync() {
// 	if (window.Worker) {
// 		if(funscriptSyncWorker)
// 			funscriptSyncWorker.terminate();
// 		funscriptSyncWorker = new Worker('syncFunscript.js');
// 		funscriptSyncWorker.postMessage(JSON.stringify({
// 			"command": "startThread", 
// 			"funscripts": loadedFunscripts, 
// 			"remoteUserSettings": remoteUserSettings
// 		}));
// 		funscriptSyncWorker.onmessage = onFunscriptWorkerThreadRecieveMessage;
// 	}
// }

function sendMediaState() {
	//console.log("sendMediaState")
	if (selectedInputDevice == DeviceType.XTPWeb) {
		if (playingmediaItem) {
			debug("[sendMediaState] XTPWeb playingmediaItem: time:"+ videoNode.currentTime);
			postMediaState({
				"path": playingmediaItem.path,
				"playing": playingmediaItem.playing,
				"currentTime": videoNode.currentTime,
				"duration": videoNode.duration,
				"playbackSpeed": videoNode.playbackRate
			});
		} else {
			debug("[sendMediaState] XTPWeb playingmediaItem: null: time: 0");
			postMediaState({
				"path": undefined,
				"playing": false,
				"currentTime": 0,
				"duration": 0,
				"playbackSpeed": 1.0
			});
		}
	}
}

function onFunscriptWorkerThreadRecieveMessage(e) {
	isMediaFunscriptPlaying = true;
	var data;
	if (typeof e.data === "string")
		data = JSON.parse(e.data);
	else
		data = e.data;
	switch (data["command"]) {
		case "sendTcode":
			sendTcode(data["tcode"])
			break;
		case "getMediaState":
			sendMediaState();
			break;
		case "end":
			funscriptSyncWorker.terminate();
			funscriptSyncWorker = null;
			break;
	}
}
//Settings
function openSettings() {
	getServerSessions();
	settingsNode.style.visibility = "visible";
	settingsNode.style.opacity = 1;
	document.getElementById("settingsTabs").style.display = "block";
	if (!speechNotInbrowser && (!systemVoices || systemVoices.length === 0))
		disableTextToSpeech("No voices found");
}

function closeSettings() {
	settingsNode.style.visibility = "hidden";
	settingsNode.style.opacity = 0;
	document.getElementById("settingsTabs").style.display = "none";
}

function openMetaDataModal(mediaItem) {
	if(!mediaItem) {
		if(!playingmediaItem)
			return;
		mediaItem = playingmediaItem;
	}
	selectedMediaItemForMetaData = mediaItem;
	const selectedMediaItemMetaData = selectedMediaItemForMetaData["metaData"];
	document.getElementById("mediaOffset").value = selectedMediaItemMetaData["offset"];
	document.getElementById("moneyShotMillis").value = selectedMediaItemMetaData["moneyShotMillis"];
	document.getElementById("funscriptModifier").value = selectedMediaItemMetaData["funscriptModifier"];

	document.getElementById("metadataDatePath").innerText = selectedMediaItemMetaData["libraryItemPath"];
	document.getElementById("metadataDateAdded").innerText = selectedMediaItemMetaData["dateAdded"];
	document.getElementById("metadataDateHasAlternate").checked = selectedMediaItemMetaData["hasAlternate"];
	
	document.getElementById("metadataDateCreated").innerText = mediaItem.modifiedDate;
	const metadataDateFunscripts = document.getElementById("metadataDateFunscripts");
	metadataDateFunscripts.innerText = "";
	if(selectedMediaItemMetaData.scripts)
		selectedMediaItemMetaData.scripts.forEach(x => 
	{ 
		const fileExt = (x.track.length > 0 ? "." + x.track : "") ;
		metadataDateFunscripts.innerHTML += x.filename + fileExt + (selectedMediaItemMetaData.scripts.indexOf(x) < selectedMediaItemMetaData.scripts.length ? "<br>" : "");
	});
	// const metadataDateSFMATracks = document.getElementById("metadataDateSFMATracks");
	// metadataDateFunscripts.innerText = "";
	// if(selectedMediaItemMetaData.MFSTracks)
	// 	selectedMediaItemMetaData.MFSTracks.forEach(x => metadataDateSFMATracks.innerHTML += x + (selectedMediaItemMetaData.MFSTracks.indexOf(x) < selectedMediaItemMetaData.MFSTracks.length ? ", " : ""));
	// const metadataDateMFSFunscripts = document.getElementById("metadataDateMFSFunscripts");
	// metadataDateMFSFunscripts.innerText = "";
	// if(selectedMediaItemMetaData.MFSScripts)
	// 	selectedMediaItemMetaData.MFSScripts.forEach(x => metadataDateMFSFunscripts.innerHTML += x + '<br>');

	//MediaItem: 
	//duration
	// Metadata:
	//subtitle
	//hasAlternate
	//isSFMA
	//isMFS
	//thumbExtractError
	//MFSScripts[]
	//MFSTracks[]
	//scripts[]
	//bookmarks[{Name, Time}]
	const tagCheckboxes = document.getElementsByName(metadataTagCheckboxesName);
	tagCheckboxes.forEach(x => {
		x.checked = selectedMediaItemMetaData.tags.findIndex(y => y == x.value) > -1;
	})
	mediaItemSettingsModalNode.style.visibility = "visible";
	mediaItemSettingsModalNode.style.opacity = 1;
}
function closeMetaDataModal() {
	mediaItemSettingsModalNode.style.visibility = "hidden";
	mediaItemSettingsModalNode.style.opacity = 0;
	document.getElementById("saveMediaItemMetaDataButton").disabled = true;
}
function openAlternateScriptsModal(mediaItem) {
	if(!mediaItem) {
		if(!playingmediaItem)
			return;
		mediaItem = playingmediaItem;
	}
	var alternateScriptsModal = document.getElementById("alternateScriptsModal");
	alternateScriptsModal.style.visibility = "visible";
	alternateScriptsModal.style.opacity = 1;
}
function deleteMediaItem(mediaItem) {
	if(!mediaItem)
		return;
	if(playingmediaItem && mediaItem.id == playingmediaItem.id) {
		userError("Cannot delete currently playing item.");
		return;
	}
	showAlertWindow("Delete media item", `Are you sure you want to delete the media item: "${mediaItem.displayName}"<br>
		This will delete the following items:<br><br>&nbsp&nbsp*All funscripts<br>&nbsp&nbsp*Thumbnails<br>&nbsp&nbsp*Metadata<br><br>This action cannot be undone!!`, function() {
			closeAlertWindow();
			sendDeleteMediaItem(mediaItem);
		});
}
function closeAlternateScriptsModal() {
	var alternateScriptsModal = document.getElementById("alternateScriptsModal");
	alternateScriptsModal.style.visibility = "hidden";
	alternateScriptsModal.style.opacity = 0;
}
function saveMetaData(mediaItem) {
	if(!mediaItem) {
		if(!selectedMediaItemForMetaData)
			return;
		mediaItem = selectedMediaItemForMetaData;
	}
	mediaItem.metaData["offset"] = parseInt(document.getElementById("mediaOffset").value);
	mediaItem.metaData["moneyShotMillis"] = parseInt(document.getElementById("moneyShotMillis").value);
	mediaItem.metaData["funscriptModifier"] = parseInt(document.getElementById("funscriptModifier").value);
	postMediaItemMetaData(mediaItem);
}

function metaDataChange() {
	document.getElementById("saveMediaItemMetaDataButton").disabled = false;
}

function addToSelectedMetaDataOffset(amount) {
	var node = document.getElementById("mediaOffset");
	var value = parseInt(node.value);
	value += amount;
	node.value = value;
	metaDataChange();
}
function addToSelectedMetaDataModifier(amount) {
	var node = document.getElementById("funscriptModifier");
	var value = parseInt(node.value);
	value += amount;
	node.value = value;
	metaDataChange();
}

function resetMoneyShot() {
	document.getElementById("moneyShotMillis").value = -1;
	metaDataChange();
}

var onMetadataTagCheckboxClicked = function (tagCheckbox) {
	return function () {
		let tagsChanged = false;
		if(tagCheckbox && selectedMediaItemForMetaData) {
			const selectedMediaItemMetaData = selectedMediaItemForMetaData["metaData"];
			const index = selectedMediaItemMetaData.tags.findIndex(x => x == tagCheckbox.value);
			if(tagCheckbox.checked && index == -1) {
				selectedMediaItemMetaData.tags.push(tagCheckbox.value);
				tagsChanged = true;
			} else if(!tagCheckbox.checked && index > -1) {
				selectedMediaItemMetaData.tags.splice(index, 1);
				tagsChanged = true;
			}
		}
		if(tagsChanged)
			metaDataChange();
	}
};

function tabClick(tab, tabNumber) {
	var allTabs = document.getElementsByClassName("tab-section-tab")
	for (var i = 0; i < allTabs.length; i++) {
		if (i == tabNumber)
			continue;
		var otherTab = allTabs[i];
		otherTab.style.backgroundColor = "#5E6B7F";
	}
	var allContent = document.getElementsByClassName("tab-content")
	for (var i = 0; i < allContent.length; i++) {
		if (i == tabNumber)
			continue;
		var content = allContent[i];
		content.style.display = 'none';
		content.style.opacity = "0";
	}
	allContent[tabNumber].style.display = 'block';
	allContent[tabNumber].style.opacity = "1";
	tab.style.backgroundColor = '#8DA1BF';
}

function getCurrentDisplayedMediaNodes() {
	var displayedElementIDs = Array.from(document.querySelectorAll(".media-item:not([hidden])")).map(x => x.id);
	return mediaListDisplayed.filter(x => {
		return displayedElementIDs.includes(x.id);
	});
}

function showChange(value) {
	if (!value)
		showGlobal = "All";
	else
		showGlobal = value;
	window.localStorage.setItem("show", JSON.stringify(value));
	mediaListDisplayed = getDisplayedMediaList(value, true);
	loadMedia(mediaListDisplayed);
	filter();
}

function sortChange(value) {
	sort(value, true);
	mediaListDisplayed = getDisplayedMediaList(showGlobal, false);
	loadMedia(mediaListDisplayed);
	filter();
}

function thumbSizeChange(value) {
	setThumbSize(value, true);
	loadMedia(mediaListDisplayed);
	filter();
}

async function setupSliders() {
	// Initialize Sliders
	var availableChannels = remoteUserSettings.availableChannelsArray;
	var tcodeRanges = document.getElementById("tcodeRanges");
	if(!availableChannels || availableChannels.length == 0) {
		console.error("availableChannels was null or empty when setupSliders was called");
		return;
	}
	removeAllChildNodes(tcodeRanges);
	for (var i = 0; i < availableChannels.length; i++) {
		var channel = availableChannels[i];
		if(channel.type == ChannelType.HalfOscillate)
			continue;

		var formElementNode = document.createElement("div");
		formElementNode.classList.add("formElement");

		var labelNode = document.createElement("label");
		labelNode.classList.add("range-label")
		labelNode.innerText = channel.friendlyName;
		labelNode.for = channel.channel;
		formElementNode.appendChild(labelNode);

		var sectionNode = document.createElement("section");
		sectionNode.classList.add("range-slider");
		sectionNode.id = channel.channel;
		formElementNode.appendChild(sectionNode);

		var rangeValuesNode = document.createElement("span");
		rangeValuesNode.classList.add("range-values")

		var input1Node = document.createElement("input");
		input1Node.type = "range";
		input1Node.min = channel.min;
		input1Node.max = channel.max - 1;
		input1Node.value = channel.userMin;

		var input2Node = document.createElement("input");
		input2Node.type = "range";
		input2Node.min = channel.min + 1;
		input2Node.max = channel.max;
		input2Node.value = channel.userMax;

		if (userAgentIsDeo) {
			formElementNode.style.height = "50px"
			labelNode.style.height = "50px"
		} else {
			input1Node.classList.add("range-input");
			input2Node.classList.add("range-input");
		}
		input1Node.oninput = function (input1Node, input2Node, rangeValuesNode, channel) {
			var slide1 = parseInt(input1Node.value);
			var slide2 = parseInt(input2Node.value);
			var slideMid = Math.round((slide2 + slide1) / 2);
			rangeValuesNode.innerText = slide1 + " - " + slideMid + " - " + slide2;
			if (slide2 < slide1) {
				input2Node.value = slide1 + 1;
				remoteUserSettings.availableChannels[channel.channel].userMax = input2Node.value;
			}
			remoteUserSettings.availableChannels[channel.channel].userMin = slide1;
			remoteUserSettings.availableChannels[channel.channel].userMid = slideMid;
			sendTCode(channel.channel + input1Node.value.toString().padStart(4, '0') + "S2000");
			//markXTPFormDirty();
			var debouncerOBJ = debounceTracker[channel.channel + "min"];
			if(debouncerOBJ)
				clearTimeout(debouncerOBJ);
			debounceTracker[channel.channel + "min"] = setTimeout(function () {
				sendTCodeRange(channel.channel, parseInt(input1Node.value), parseInt(input2Node.value));
				debounceTracker[channel.channel + "min"] = undefined;
			}, 1000);
		}.bind(input1Node, input1Node, input2Node, rangeValuesNode, channel);

		input2Node.oninput = function (input1Node, input2Node, rangeValuesNode, channel) {
			var slide1 = parseInt(input1Node.value);
			var slide2 = parseInt(input2Node.value);
			var slideMid = Math.round((slide2 + slide1) / 2);
			rangeValuesNode.innerText = slide1 + " - " + slideMid + " - " + slide2;
			if (slide1 > slide2) {
				input1Node.value = slide2 - 1;
				remoteUserSettings.availableChannels[channel.channel].userMin = input1Node.value;
			}
			remoteUserSettings.availableChannels[channel.channel].userMax = slide2;
			remoteUserSettings.availableChannels[channel.channel].userMid = slideMid;
			sendTCode(channel.channel + input2Node.value.toString().padStart(4, '0') + "S2000");
			//markXTPFormDirty();
			var debouncerOBJ = debounceTracker[channel.channel + "max"];
			if(debouncerOBJ)
				clearTimeout(debouncerOBJ);
			debounceTracker[channel.channel + "max"] = setTimeout(function () {
				sendTCodeRange(channel.channel, parseInt(input1Node.value), parseInt(input2Node.value));
				debounceTracker[channel.channel + "max"] = undefined;
			}, 1000);
		}.bind(input2Node, input1Node, input2Node, rangeValuesNode, channel);

		var minIncrementButton = document.createElement("button");
		minIncrementButton.classList.add("min-max-button");
		minIncrementButton.innerText = "+";
		minIncrementButton.onclick = function (input1Node, input2Node) {
			const minValue = parseInt(input1Node.value);
			const maxValue = parseInt(input2Node.value);
			const newValue = minValue + rangeChangeAmount;
			input1Node.value = newValue <= maxValue ? newValue : maxValue - rangeChangeAmount;
			input1Node.dispatchEvent(new Event('input', { bubbles: true }));
		}.bind(input1Node, input1Node, input2Node, channel);

		var minDecrementButton = document.createElement("button");
		minDecrementButton.classList.add("min-max-button");
		minDecrementButton.innerText = "-";
		minDecrementButton.onclick = function (input1Node, channel) {
			const minValue = parseInt(input1Node.value);
			const newValue = minValue - rangeChangeAmount;
			input1Node.value = newValue >= remoteUserSettings.availableChannels[channel.channel].min ? newValue : remoteUserSettings.availableChannels[channel.channel].min;
			input1Node.dispatchEvent(new Event('input', { bubbles: true }));
		}.bind(input1Node, input1Node, channel);

		var maxIncrementButton = document.createElement("button");
		maxIncrementButton.classList.add("min-max-button");
		maxIncrementButton.innerText = "+";
		maxIncrementButton.onclick = function (input2Node, channel) {
			const maxValue = parseInt(input2Node.value);
			const newValue = maxValue + rangeChangeAmount;
			input2Node.value = newValue <= remoteUserSettings.availableChannels[channel.channel].max ? newValue : remoteUserSettings.availableChannels[channel.channel].max;
			input2Node.dispatchEvent(new Event('input', { bubbles: true }));
		}.bind(input2Node, input2Node, channel);

		var maxDecrementButton = document.createElement("button");
		maxDecrementButton.classList.add("min-max-button");
		maxDecrementButton.innerText = "-";
		maxDecrementButton.onclick = function (input1Node, input2Node) {
			const minValue = parseInt(input1Node.value);
			const maxValue = parseInt(input2Node.value);
			const newValue = maxValue - rangeChangeAmount;
			input2Node.value = newValue >= minValue ? newValue : minValue + rangeChangeAmount;
			input2Node.dispatchEvent(new Event('input', { bubbles: true }));
		}.bind(input1Node, input1Node, input2Node, channel);

		var minmaxButtonSpanRow = document.createElement("span");
		minmaxButtonSpanRow.classList.add("min-max-buttons");
		var minButtonSpan = document.createElement("span");
		minButtonSpan.appendChild(minDecrementButton);
		minButtonSpan.appendChild(minIncrementButton);
		var maxButtonSpan = document.createElement("span");
		maxButtonSpan.appendChild(maxDecrementButton);
		maxButtonSpan.appendChild(maxIncrementButton);

		minmaxButtonSpanRow.appendChild(minButtonSpan);
		minmaxButtonSpanRow.appendChild(rangeValuesNode);
		minmaxButtonSpanRow.appendChild(maxButtonSpan);

		sectionNode.appendChild(minmaxButtonSpanRow);
		sectionNode.appendChild(input1Node);
		sectionNode.appendChild(input2Node);

		var slide1 = parseInt(input1Node.value);
		var slide2 = parseInt(input2Node.value);
		var slideMid = Math.round((slide2 + slide1) / 2);
		rangeValuesNode.innerText = slide1 + " - " + slideMid + " - " + slide2;

		tcodeRanges.appendChild(formElementNode);
	}
}

async function setupMotionModifiers() {
	//var tab = document.getElementById("tabMotion");
	var motionRandomContainer = document.getElementById("motionRandomContainer");
	removeAllChildNodes(motionRandomContainer);

	var formElementNode = document.createElement("div");
	formElementNode.classList.add("formElement");
	

	// var headerDivNode = document.createElement("div");
	// headerDivNode.classList.add("tab-content-header");
	// var headerNode = document.createElement("div");
	// headerNode.innerText = "Motion modifier"
	// headerNode.classList.add("tab-content-header-main");
	var subtextNode = document.createElement("div");
	subtextNode.classList.add("tab-content-header-eyebrow");
	subtextNode.innerText = "Add random motion to other channels"
	//headerDivNode.appendChild(headerNode);
	motionRandomContainer.appendChild(subtextNode);

	var labelNode = document.createElement("label");
	labelNode.innerText = "Enabled";
	labelNode.for = "multiplierEnabled"

	var sectionNode = document.createElement("section");
	sectionNode.classList.add("form-group-section");
	sectionNode.id = "multiplierEnabled";

	var multiplierEnabledNode = document.createElement("input");
	multiplierEnabledNode.id = "multiplierEnabled";
	multiplierEnabledNode.type = "checkbox";
	multiplierEnabledNode.checked = remoteUserSettings.multiplierEnabled;
	multiplierEnabledNode.setAttribute("title", "Global random motion toggle.")

	multiplierEnabledNode.oninput = function (event) {
		remoteUserSettings.multiplierEnabled = event.target.checked;
		toggleMotionModifierState(event.target.checked);
		markXTPFormDirty();
	}.bind(multiplierEnabledNode);

	sectionNode.appendChild(multiplierEnabledNode);

	const enabledHelptext = "The will toggle whether this channel is included in the random motion generation or not.";
	const linkToHelptext = "This will match the values of the linked channel 1:1 with modifiers speed and offset applied.";
	const linkInvertedHelpText = "Inverts the selected linked channel if exists";
	const speedHelptext = "The percentage of the linked scripts time to modify the speed.\nIf the speed is 0.1, the speed will be 10% of the linked script or 90% slower.\nA value of 2 will be 200% faster.\nMinimum value is 0.01";
	const offsetHelpText = "The percentage of the linked scripts time to offset.\nIf the offset is 0.1 and the parent action interval is 300ms, the offset will be 30ms after the linked script event.\nCan be any value between -1.00 and 1.00";
	var headers = [
		//"Modifier", 
		{text: "Link to script", helpText: linkToHelptext}, 
		{text: "Link inverted", helpText: linkInvertedHelpText}, 
		{text: "Speed", helpText: speedHelptext},  
		{text: "Offset", helpText: offsetHelpText}
	]
	headers.forEach(element => {
		var gridHeaderNode = document.createElement("div");
		gridHeaderNode.classList.add("form-group-control");
		gridHeaderNode.classList.add("form-group-control-header");
		var gridHeaderContentNode = document.createElement("span");
		gridHeaderContentNode.innerText = element.text;
		gridHeaderContentNode.setAttribute("title", element.helpText)
		gridHeaderNode.appendChild(gridHeaderContentNode);
		sectionNode.appendChild(gridHeaderNode);
	});


	formElementNode.appendChild(labelNode);
	formElementNode.appendChild(sectionNode);

	// tab.appendChild(headerDivNode);
	motionRandomContainer.appendChild(formElementNode);

	var availableChannels = remoteUserSettings.availableChannelsArray;
	for (var i = 0; i < availableChannels.length; i++) {

		var channel = availableChannels[i];
		if(channel.type == ChannelType.HalfOscillate)
			continue;
		var channelName = channel.channel;

		var formElementNode = document.createElement("div");
		formElementNode.classList.add("formElement");

		var labelNode = document.createElement("label");
		labelNode.innerText = channel.friendlyName;
		labelNode.for = channelName;
		formElementNode.appendChild(labelNode);


		/* 	value["speedEnabled"] = availableChannels->value(channel).speedEnabled;
			value["speedValue"] = availableChannels->value(channel).speedValue;
			value["dimension"] = (int)availableChannels->value(channel).Dimension;
			value["friendlyName"] = availableChannels->value(channel).FriendlyName;
			value["linkToRelatedMFS"] = availableChannels->value(channel).LinkToRelatedMFS;
			value["max"] = availableChannels->value(channel).Max;
			value["mid"] = availableChannels->value(channel).Mid;
			value["min"] = availableChannels->value(channel).Min;
			value["multiplierEnabled"] = availableChannels->value(channel).MultiplierEnabled;
			value["multiplierValue"] = availableChannels->value(channel).MultiplierValue;
			value["relatedChannel"] = availableChannels->value(channel).RelatedChannel; */

		var sectionNode = document.createElement("section");
		sectionNode.setAttribute("name", "motionModifierSection");
		sectionNode.classList.add("form-group-section");
		sectionNode.id = channelName;

		var enabledValueNode = document.createElement("div");
		enabledValueNode.classList.add("form-group-control");

		var multiplierEnabledNode = document.createElement("input");
		multiplierEnabledNode.setAttribute("name", "motionModifierInput");
		multiplierEnabledNode.type = "checkbox";
		multiplierEnabledNode.checked = channel.multiplierEnabled;
		multiplierEnabledNode.setAttribute("title", enabledHelptext);

		multiplierEnabledNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].multiplierEnabled = event.target.checked;
			markXTPFormDirty();
		}.bind(multiplierEnabledNode, channelName);

		// var multiplierValueNode = document.createElement("input");
		// multiplierValueNode.setAttribute("name", "motionModifierInput");
		// multiplierValueNode.value = channel.multiplierValue;

		// multiplierValueNode.oninput = function (channelName, event) {
		// 	var value = parseFloat(event.target.value);
		// 	if (value) {
		// 		remoteUserSettings.availableChannels[channelName].multiplierValue = value;
		// 		markXTPFormDirty();
		// 	}
		// }.bind(multiplierValueNode, channelName);

		enabledValueNode.appendChild(multiplierEnabledNode);
		//enabledValueNode.appendChild(multiplierValueNode);

		var linkedEnabledValueNode = document.createElement("div");
		linkedEnabledValueNode.classList.add("form-group-control");

		var linkToRelatedMFSNode = document.createElement("input");
		linkToRelatedMFSNode.setAttribute("name", "motionModifierInput");
		linkToRelatedMFSNode.type = "checkbox";
		linkToRelatedMFSNode.setAttribute("title", linkToHelptext)
		linkToRelatedMFSNode.checked = channel.linkToRelatedMFS;

		linkToRelatedMFSNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].linkToRelatedMFS = event.target.checked;
			markXTPFormDirty();
		}.bind(linkToRelatedMFSNode, channelName);

		var relatedChannelNode;
		if(!userAgentIsHereSphere)
		{
			relatedChannelNode = document.createElement("select");
			relatedChannelNode.setAttribute("name", "motionModifierInput");

			availableChannels.forEach(element => {
				if (element.channel !== channel.channel) {
					var relatedChannelOptionNode = document.createElement("option");
					relatedChannelOptionNode.innerHTML = element.friendlyName;
					relatedChannelOptionNode.value = element.axisName;
					relatedChannelNode.appendChild(relatedChannelOptionNode);
				}
			});
			relatedChannelNode.value = channel.relatedChannel;

			relatedChannelNode.oninput = function (channelName, event) {
				remoteUserSettings.availableChannels[channelName].relatedChannel = event.target.value;
				markXTPFormDirty();
			}.bind(relatedChannelNode, channelName);
		} else {
			relatedChannelNode = document.createElement("button");
			relatedChannelNode.setAttribute("name", "motionModifierInput");
			//relatedChannelNode.classList.add("form-group-control--selectButton");
			//relatedChannelNode.style = "max-width: 100px; min-width: 24px; align-self: center;"

			const relatedChannel = availableChannels.find(x => x.axisName == channel.relatedChannel);
			relatedChannelNode.innerText = relatedChannel.friendlyName;

			relatedChannelNode.onclick = function (channelName, event) {
				var labelValueArray = availableChannels.map((x) => ({value: x.axisName, label: x.friendlyName}));
				showSelectWindow("Link channel to", "Select channel", labelValueArray, (value) => {
					let newRelatedChannel = availableChannels.find(x => x.axisName == value);
					this.innerText = newRelatedChannel.friendlyName;
					remoteUserSettings.availableChannels[channelName].relatedChannel = value;
					closeSelectWindow();
					onSaveToXTPClick();
				});
			}.bind(relatedChannelNode, channelName);
		}

		var linkedInvertedNode = document.createElement("input");
		linkedInvertedNode.setAttribute("name", "motionModifierInput");
		linkedInvertedNode.type = "checkbox";
		linkedInvertedNode.setAttribute("title", linkInvertedHelpText)
		linkedInvertedNode.checked = channel.linkedInverted;

		linkedInvertedNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].linkedInverted = event.target.checked;
			markXTPFormDirty();
		}.bind(linkedInvertedNode, channelName);

		linkedEnabledValueNode.appendChild(linkToRelatedMFSNode);
		linkedEnabledValueNode.appendChild(relatedChannelNode);
		linkedEnabledValueNode.appendChild(linkedInvertedNode);
		linkedEnabledValueNode.setAttribute("title", linkToHelptext);

		var speedEnabledValueNode = document.createElement("div");
		speedEnabledValueNode.classList.add("form-group-control");

		var speedEnabledNode = document.createElement("input");
		speedEnabledNode.setAttribute("name", "motionModifierInput");
		speedEnabledNode.type = "checkbox";
		speedEnabledNode.checked = channel.speedEnabled;
		speedEnabledNode.setAttribute("title", speedHelptext);

		speedEnabledNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].speedEnabled = event.target.checked;
			markXTPFormDirty();
		}.bind(speedEnabledNode, channelName);

		var speedValueNode = document.createElement("input");
		speedValueNode.setAttribute("name", "motionModifierInput");
		speedValueNode.setAttribute("min", "0.01");
		speedValueNode.setAttribute("step", "0.01");
		speedValueNode.setAttribute("title", speedHelptext);
		speedValueNode.type = "number";
		speedValueNode.value = round(channel.speedValue, 2);

		speedValueNode.oninput = function (channelName, event) {
			if(!event.target.validity.valid)
				return;
			var value = parseFloat(event.target.value);
			if (value != undefined && value != null) {
				remoteUserSettings.availableChannels[channelName].speedValue = round(value, 2);
				markXTPFormDirty();
			}
		}.bind(speedValueNode, channelName);

		speedEnabledValueNode.appendChild(speedEnabledNode);
		speedEnabledValueNode.appendChild(speedValueNode);


		var offsetValueNode = document.createElement("input");
		offsetValueNode.setAttribute("name", "motionModifierInput");
		offsetValueNode.setAttribute("min", "-1");
		offsetValueNode.setAttribute("max", "1");
		offsetValueNode.setAttribute("step", "0.01");
		offsetValueNode.setAttribute("title", offsetHelpText);
		offsetValueNode.type = "number";
		offsetValueNode.value = round(channel.offset, 2);

		offsetValueNode.oninput = function (channelName, event) {
			if(!event.target.validity.valid)
				return;
			var value = parseFloat(event.target.value);
			if (value != undefined && value != null) {
				remoteUserSettings.availableChannels[channelName].offset = value;
				markXTPFormDirty();
			}
		}.bind(offsetValueNode, channelName);

		speedEnabledValueNode.appendChild(speedEnabledNode);
		speedEnabledValueNode.appendChild(speedValueNode);

		speedEnabledValueNode.appendChild(offsetValueNode);

		sectionNode.appendChild(enabledValueNode);
		sectionNode.appendChild(linkedEnabledValueNode);
		sectionNode.appendChild(speedEnabledValueNode);

		formElementNode.appendChild(sectionNode);

		motionRandomContainer.appendChild(formElementNode);
	}

	toggleMotionModifierState(remoteUserSettings.multiplierEnabled);
	setUpInversionMotionModifier();
	setUpInversionGradientModifier();
}
function toggleMotionModifierState(enabled) {
	var motionModifierElements = document.getElementsByName("motionModifierInput");
	motionModifierElements.forEach(element => {
		element.disabled = !enabled;
	})
}
async function setUpInversionMotionModifier() {

	//var tab = document.getElementById("tabMotion");
	var motionInversionContainer = document.getElementById("motionInversionContainer");
	removeAllChildNodes(motionInversionContainer);

	var formElementNode = document.createElement("div");
	formElementNode.classList.add("formElement");

	// var headerDivNode = document.createElement("div");
	// headerDivNode.classList.add("tab-content-header");
	var subtextNode = document.createElement("div");
	subtextNode.classList.add("tab-content-header-eyebrow");
	subtextNode.innerText = "Invert funscript"
	//headerDivNode.appendChild(subtextNode);

	motionInversionContainer.appendChild(subtextNode);


	var availableChannels = remoteUserSettings.availableChannelsArray;
	for (var i = 0; i < availableChannels.length; i++) {

		var channel = availableChannels[i];
		if(channel.type == ChannelType.HalfOscillate)
			continue;
		var channelName = channel.channel;

		var formElementNode = document.createElement("div");
		formElementNode.classList.add("formElement", "formElement--label-large");
		

		var labelNode = document.createElement("label");
		labelNode.innerText = channel.friendlyName;
		labelNode.for = channel.channel + "Inverted";
		formElementNode.appendChild(labelNode);


		/* value["inverted"] = availableChannels->value(channel).Inverted; */

		var sectionNode = document.createElement("section");
		sectionNode.setAttribute("name", "motionModifierInvertedSection");
		sectionNode.classList.add("form-group-section");
		sectionNode.id = channel.channel + "Inverted";

		var enabledValueNode = document.createElement("div");
		enabledValueNode.classList.add("form-group-control");

		var invertedEnabledNode = document.createElement("input");
		invertedEnabledNode.setAttribute("name", "motionModifierInputInverted");
		invertedEnabledNode.type = "checkbox";
		invertedEnabledNode.checked = channel.funscriptInverted;

		invertedEnabledNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].funscriptInverted = event.target.checked;
			markXTPFormDirty();
		}.bind(invertedEnabledNode, channelName);

		enabledValueNode.appendChild(invertedEnabledNode);
		sectionNode.appendChild(enabledValueNode);
		formElementNode.appendChild(sectionNode);

		motionInversionContainer.appendChild(formElementNode);
	}
}

function setUpInversionGradientModifier() {
	var motionGradientContainer = document.getElementById("motionGradientContainer");
	removeAllChildNodes(motionGradientContainer);

	var formElementNode = document.createElement("div");
	formElementNode.classList.add("formElement");

	var subtextNode = document.createElement("div");
	subtextNode.classList.add("tab-content-header-eyebrow");
	subtextNode.innerText = "Gradient"

	motionGradientContainer.appendChild(subtextNode);


	var availableChannels = remoteUserSettings.availableChannelsArray;
	for (var i = 0; i < availableChannels.length; i++) {

		var channel = availableChannels[i];
		if(channel.type == ChannelType.HalfOscillate)
			continue;
		var channelName = channel.channel;

		var formElementNode = document.createElement("div");
		formElementNode.classList.add("formElement", "formElement--label-large");
		

		var labelNode = document.createElement("label");
		labelNode.innerText = channel.friendlyName;
		labelNode.for = channel.channel + "Gradient";
		formElementNode.appendChild(labelNode);

		var sectionNode = document.createElement("section");
		sectionNode.setAttribute("name", "motionModifierInvertedSection");
		sectionNode.classList.add("form-group-section");
		sectionNode.id = channel.channel + "Gradient";

		var enabledValueNode = document.createElement("div");
		enabledValueNode.classList.add("form-group-control");

		var gradientEnabledNode = document.createElement("input");
		gradientEnabledNode.setAttribute("name", "motionModifierInputGradient");
		gradientEnabledNode.type = "checkbox";
		gradientEnabledNode.checked = channel.gradient;

		gradientEnabledNode.oninput = function (channelName, event) {
			remoteUserSettings.availableChannels[channelName].gradient = event.target.checked;
			markXTPFormDirty();
		}.bind(gradientEnabledNode, channelName);

		enabledValueNode.appendChild(gradientEnabledNode);
		sectionNode.appendChild(enabledValueNode);
		formElementNode.appendChild(sectionNode);

		motionGradientContainer.appendChild(formElementNode);
	}
}

function markXTPFormDirty() {
	xtpFormDirty = true;
	var saveToXTPButton = document.getElementById("saveToXTPButton");
	saveToXTPButton.disabled = false;
}

function markXTPFormClean() {
	xtpFormDirty = false;
	var saveToXTPButton = document.getElementById("saveToXTPButton");
	saveToXTPButton.disabled = true;
}

function setupConnectionsTab() {
	/*   
		connectionSettingsJson["networkAddress"] = SettingsHandler::getServerAddress();
		connectionSettingsJson["networkPort"] = SettingsHandler::getServerPort();
		connectionSettingsJson["serialPort"] = SettingsHandler::getSerialPort(); */
	selectedInputDevice = remoteUserSettings.connection.input.selectedDevice;
	if (selectedSyncConnectionGlobal && selectedSyncConnectionGlobal != selectedInputDevice) {
		sendInputDeviceConnectionChange(selectedSyncConnectionGlobal, true);
		selectedInputDevice = selectedSyncConnectionGlobal;
	}
	switch (selectedInputDevice) {
		case DeviceType.Deo:
			document.getElementById("connectionDeoVR").checked = true;
			break;
		case DeviceType.Whirligig:
			document.getElementById("connectionWhirligig").checked = true;
			break;
		case DeviceType.XTPWeb:
			document.getElementById("connectionXTPWeb").checked = true;
			break;
		case DeviceType.None:
			document.getElementById("connectionInputNone").checked = true;
			break;
	}
	document.getElementById("deoVRAddress").value = remoteUserSettings.connection.input.deoAddress
	document.getElementById("deoVRPort").value = remoteUserSettings.connection.input.deoPort
	document.getElementById("connectionGamepad").checked = remoteUserSettings.connection.input.gamePadEnabled;

	selectedOutputDevice = remoteUserSettings.connection.output.selectedDevice;
	if (selectedOutputConnectionGlobal && selectedOutputConnectionGlobal != selectedOutputDevice) {
		sendOutputDeviceConnectionChange(selectedOutputConnectionGlobal, true);
		selectedOutputDevice = selectedOutputConnectionGlobal;
	}
	switch (selectedOutputDevice) {
		case DeviceType.None:
			document.getElementById("connectionOutputNone").checked = true;
			break;
		case DeviceType.Network:
			document.getElementById("connectionNetwork").checked = true;
			break;
		case DeviceType.Serial:
			document.getElementById("connectionSerial").checked = true;
			break;
	}
	
	document.getElementById("networkAddress").value = remoteUserSettings.connection.output.networkAddress
	document.getElementById("networkPort").value = remoteUserSettings.connection.output.networkPort
	document.getElementById("networkProtocolWebsocket").checked = remoteUserSettings.connection.output.networkProtocol == NetworkProtocol.WEBSOCKET;
	document.getElementById("serialPort").value = remoteUserSettings.connection.output.serialPort
}

var debouncer;
function webSocketAddressChange(e) {
	if (debouncer) {
		clearTimeout(debouncer);
	}
	debouncer = setTimeout(function () {
		debouncer = null;
		deviceAddress = document.getElementById("webSocketAddress").value;
		window.localStorage.setItem("webSocketAddress", value);
	}, 500);
}

function defaultLocalSettings() {
	showAlertWindow("Confirm", "Are you sure you want to reset ALL local settings to default? Note: This only resets the settings in this browser. Your settings stored in XTP will remain.", function () {
		window.localStorage.clear();
		window.close();//Does not work
		closeAlertWindow();
	});
}

function deleteLocalSettings() {
	showAlertWindow("Confirm", "Are you sure you want to delete ALL settings from localStorage and close the window?", function () {
		window.localStorage.clear();
		window.location.reload();
		closeAlertWindow();
	});
}
function onDeoVRAddressChange(input) {
	if(!input.value || input.value.trim().length === 0) {
		userError("Invalid Deo/Heresphere network address");
		return;
	}
	remoteUserSettings.connection.input.deoAddress = input.value.trim();
	markXTPFormDirty();
}
function onDeoVRPortChange(input) {
	if(!input.value || input.value.trim().length === 0) {
		userError("Invalid Deo/Heresphere network port");
		return;
	}
	remoteUserSettings.connection.input.deoPort = input.value.trim();
	markXTPFormDirty();
}
function onNetworkAddressChange(input) {
	if(!input.value || input.value.trim().length === 0) {
		userError("Invalid network address");
		return;
	}
	remoteUserSettings.connection.output.networkAddress = input.value.trim();
	markXTPFormDirty();
}
function onNetworkPortChange(input) {
	if(!input.value || input.value.trim().length === 0) {
		userError("Invalid network port");
		return;
	}
	remoteUserSettings.connection.output.networkPort = input.value.trim();
	markXTPFormDirty();
}
function onNetworkWebsocketChange(input) {
	remoteUserSettings.connection.output.networkProtocol = input.checked ? NetworkProtocol.WEBSOCKET : NetworkProtocol.UDP;
	markXTPFormDirty();
}

function onSerialPortChange(input) {
	remoteUserSettings.connection.output.serialPort = input.value;
	markXTPFormDirty();
}

function onAddChannelProfile() {
	showGetTextWindow("Add new channel profile", "Enter the name of the new profile",
		(name) => { 
			addChannelProfile(name);
			closeTextWindow();
		}
	);
}

function onDeleteChannelProfile() {
	if(remoteUserSettings.allChannelProfileNames.length < 2) {
		showAlertWindow("Error", "There must be at least 1 profile");
		return;
	}
	showAlertWindow("Delete", `Are you sure you want to delete ${remoteUserSettings.selectedChannelProfile}?\nThis action cannot be undone!`,
		() => { 
			deleteChannelProfile(remoteUserSettings.selectedChannelProfile);
			closeAlertWindow();
		}
	);
}

function onCopyToChannelProfile() {
	showGetTextWindow("Copy to new channel profile", "Enter the name of the new profile",
		(name) => { 
			cloneChannelProfile(remoteUserSettings.selectedChannelProfile, name);
			closeTextWindow();
		}
	);
}

function onCopyFromChannelProfile() {
	if(remoteUserSettings.allChannelProfileNames.length < 2) {
		showAlertWindow("Error", "There is only one profile");
		return;
	}
	let otherProfiles = JSON.parse(JSON.stringify(remoteUserSettings.allChannelProfileNames));
	otherProfiles.splice(remoteUserSettings.allChannelProfileNames.indexOf(remoteUserSettings.selectedChannelProfile), 1);
	showSelectWindow("Copy values from", `Select a profile to copy from:`, otherProfiles,
		(from) => { 
			cloneChannelProfile(from, remoteUserSettings.selectedChannelProfile);
			closeSelectWindow();
		}
	);
}

// function connectToTcodeDevice() {
// 	webSocket = new WebSocket("ws://"+deviceAddress+"/ws");
// 	webSocket.onopen = function (event) {
// 		webSocket.send("D1");
// 	};
// 	webSocket.onmessage = function (event) {
// 		console.log(event.data);
// 		document.getElementById("webSocketStatus").innerHTML = "Connected";
// 	}
// 	webSocket.onerror = function (event) {
// 		console.log(event.data);
// 		webSocket = null;
// 		document.getElementById("webSocketStatus").innerHTML = "Error";
// 	}
// }

// function sendTcode(tcode) {
// 	console.log("Send tcode: "+tcode);
// 	if(webSocket)
// 	{
// 		webSocket.send(tcode);
// 	}
// }


// keyboardShortcuts executes the relevant functions for
// each supported shortcut key
function keyboardShortcuts(event) {
	if(!filterDebounce) {
		const { key } = event;
		switch (key) {
			case 'k':
				togglePlay();
				animatePlayback();
				if (videoNode.paused) {
					showControls();
				} else {
					hideControls();
				}
				break;
			case 'm':
				toggleMute();
				break;
			case 'f':
				toggleFullScreen();
				break;
			case 'p':
				togglePip();
				break;
			case 'ArrowRight':
				playNextVideo();
				break;
			case 'ArrowLeft':
				playPreviousVideo();
				break;
			case '+':
				volumeUp();
				break;
			case '-':
				volumeDown();
				break;
			case 'a':
				sendSkipToNextAction();
				break;
			case 'c':
				onSkipToMoneyShot();
				break;
			case 'x':
				stopVideoClick();
				break;
			
		}
	}
}