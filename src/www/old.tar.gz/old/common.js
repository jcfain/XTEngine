
var alertModelNode = document.getElementById("alertModal");
var textModelNode = document.getElementById("textModal");
var selectModelNode = document.getElementById("selectModal");

function userError(message) {
	showAlertWindow("Error", message);
}
function systemError(message) {
	showAlertWindow("System error", message);
}
function userWarning(message) {
	showAlertWindow("Warning", message);
}
function systemWarning(message) {
	showAlertWindow("System warning", message);
}
function systemSuccess(message) {
	showAlertWindow("Success!", message);
}
function showRestartRequired() {
	var restartRequiredNodes = document.getElementsByClassName("restart-required");
	for (let element of restartRequiredNodes) {
		element.style.color = "red";
		element.style.visibility = "visible";
		element.style.opacity = "1";
	}
}


function showAlertWindow(header, message, yesCallback) {
	if(alertModelNode.style.visibility != "visible") {
		var confirmButton = document.getElementById("alertConfirmButton");
		var closebutton = document.getElementById("alertCancelButton");
		var headerNode = document.getElementById("alert-modal-title");
		confirmButton.disabled = false;
		closebutton.disabled = false;
		headerNode.disabled = false;
		headerNode.innerText = header;
		var alertModalBody = document.getElementById("alertModalBody");
		if(yesCallback) {
			confirmButton.hidden = false;
			confirmButton.onclick = () => {
				confirmButton.disabled = true;
				closebutton.disabled = true;
				headerNode.disabled = true;
				yesCallback();
			}
			alertModalBody.innerHTML = message;
			closebutton.innerText = "No";
		} else {
			confirmButton.hidden = true;
			if(message)
				alertModalBody.innerHTML = message;
			closebutton.innerText = "Ok";
		}
		alertModelNode.style.visibility = "visible";
		alertModelNode.style.opacity = 1;
	} else {
		var confirmButton = document.getElementById("alertConfirmButton");
		if(!yesCallback && confirmButton.hidden) {
			var alertModalBody = document.getElementById("alertModalBody");
			alertModalBody.innerHTML += "<br>" + header + ": "+ message;
		} else {
			systemError("Alert window already opened with attempted callback");
		}
	}
}
	
function closeAlertWindow() {
	alertModelNode.style.visibility = "hidden";
	alertModelNode.style.opacity = 0;
	setTimeout(function() {
		if(alertModelNode.style.visibility != "visible") {// Already been replaced. Avoids race condition when closing one alert to open another after.
			var confirmButton = document.getElementById("alertConfirmButton");
			confirmButton.onclick = undefined;
			var alertModalBody = document.getElementById("alertModalBody");
			alertModalBody.innerText = undefined;
		}
	}, 275)
}

function showGetTextWindow(header, message, yesCallback) {
	if(textModelNode.style.visibility != "visible") {
		var textModalInput = document.getElementById("textModalInput");
		var headerNode = document.getElementById("text-modal-title");
		headerNode.innerText = header;
		var textModalLabel = document.getElementById("textModalLabel");
		textModalLabel.innerHTML = message;
		var confirmButton = document.getElementById("textConfirmButton");
		confirmButton.onclick = function(textModalInput) { 
			yesCallback(textModalInput.value);
		}.bind(textModalInput, textModalInput);
		textModelNode.style.visibility = "visible";
		textModelNode.style.opacity = 1;
	} else {
		systemError("Two text windows opened");
	}
}
	
function closeTextWindow() {
	textModelNode.style.visibility = "hidden";
	textModelNode.style.opacity = 0;
	setTimeout(function() {
		var confirmButton = document.getElementById("textConfirmButton");
		confirmButton.onclick = undefined;
		var textModalInput = document.getElementById("textModalInput");
		textModalInput.value = "";
	}, 275)
}

/// optionsArray is either string[] or [{ value: any, label: string }]
function showSelectWindow(header, message, optionsArray, yesCallback) {
	if(selectModelNode.style.visibility != "visible") {
		var selectModalInput = document.getElementById("selectModalInput");
		selectModalInput.classList.add("radio-group--select-model");
		removeAllChildNodes(selectModalInput);
		let index = 0;
		// Not currently a combo because heresphere doesnt support it.
		optionsArray.forEach(x => {
			let labelText;
			let value;
			if(typeof x === "object") {
				labelText = x.label;
				value = x.value;
			} else if(typeof x === "string") {
				labelText = x;
				value = x;
			}
			var radio = document.createElement("input");
			var label = document.createElement("label");
			label.onclick = () => {radio.checked = true;} 
			radio.type = "radio";
			radio.id = index + "SelectInput";
			radio.name = "selectWindowGroup";
			radio.value = value;
			// radio.onclick = function() {
			// 	yesCallback(this.value);
			// }
			if(optionsArray.indexOf(x) == 0)
			{
				radio.checked = true;
			}
			label.for = radio.id;
			label.innerText = labelText;
			const divContainer = document.createElement("div");
			divContainer.appendChild(radio);
			divContainer.appendChild(label);
			selectModalInput.appendChild(divContainer);
			index++;
		});
		var headerNode = document.getElementById("select-modal-title");
		headerNode.innerText = header;
		var selectModalLabel = document.getElementById("selectModalLabel");
		selectModalLabel.innerHTML = message;
		var confirmButton = document.getElementById("selectConfirmButton");
		confirmButton.onclick = function(selectModalInput) { 
			const group = document.getElementsByName("selectWindowGroup");
			let selectedValue = "";
			group.forEach(x => {
				if(x.checked) {
					selectedValue = x.value;
					return;
				}

			})
			yesCallback(selectedValue);
		}.bind(selectModalInput, selectModalInput);
		selectModelNode.style.visibility = "visible";
		selectModelNode.style.opacity = 1;
	} else {
		systemError("Two select windows opened");
	}
}
function closeSelectWindow() {
	selectModelNode.style.visibility = "hidden";
	selectModelNode.style.opacity = 0;
	setTimeout(function() {
		var confirmButton = document.getElementById("selectConfirmButton");
		confirmButton.onclick = undefined;
		var selectModalInput = document.getElementById("selectModalInput");
		removeAllChildNodes(selectModalInput);
	}, 275)
}

function createCheckBoxDiv(id, name, value, labelText, onCheckedChange) {
	const divNode = document.createElement("div");
	divNode.classList.add("system-tag-checkbox")
	const label = document.createElement("label");
	label.innerText = labelText;
	label.setAttribute("for", id);
	const checkbox = document.createElement("input");
	checkbox.type = "checkbox";
	checkbox.value = value;
	//checkbox.classList.add("styled-checkbox");
	checkbox.id = id;
	checkbox.name = name;
	checkbox.onclick = onCheckedChange(checkbox);
	divNode.appendChild(checkbox);
	divNode.appendChild(label);
	return divNode;
}

function scale(number, inMin, inMax, outMin, outMax) {
    return (((number - inMin) * (outMax - outMin)) / (inMax - inMin)) + outMin;
}

function getChannelColor(channel) {
	switch (channel)
	{
		case "L0":
			return "red";
		case "L1":
			return "yellow";
		case "L2":
			return "orange";
		case "R0":
			return "blue";
		case "R1":
			return "green";
		case "R2":
			return "purple";
		case "V0":
			return "pink";
		case "V1":
			return "aliceblue";
		case "A0":
			return "cyan";
		case "A1":
			return "magenta";
		default:
			return "white"
	}
}

function lerp(startValue, targetValue, timeScale) {
	//return startValue*timeScale + targetValue*(1-timeScale);
	return startValue + (targetValue - startValue) * timeScale;
}

function millis(lastTime = 0) {
	return Date.now() - lastTime;
}

function round(value, precision) {
    var multiplier = Math.pow(10, precision || 0);
    return Math.round(value * multiplier) / multiplier;
}

function capitalizeFirstLetter(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

function IsDirty(form) {
    for (var i=0; i<form.elements.length; i++) {
        var field = form.elements[i];
        switch (field.type) {
            case "select-multiple":
            case "select-one":
                var options = field.options;
                for (var j=0; j<options.length; j++) {
                    if(options[j].selected != options[j].defaultSelected) return true;
                }
                break;
            case "text":
            case "file":
            case "password":
                if (field.value != field.defaultValue) return true;
                break;
            case "checkbox":
            case "radio":
                if (field.checked != field.defaultChecked) return true;
                break;
        }
    }
    return false;
}