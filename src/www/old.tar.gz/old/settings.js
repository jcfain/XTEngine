const systemInfoTab = document.getElementById("systemInfoTab");

Settings = {
    loaded: false,
    SettingProfile: {
        System: 0
    },
    FormControlTypes: {
        Double: 0,
        Int: 1,
        Text: 2,
        Radio: 3,
        Combo: 4,
        Checkbox: 5,
        DateTime: 6,
        Date: 7,
        Time: 8
    },
    debounceer: {},
    debounceerTimeout: 1000,
    createForm(group) {
        let div = document.createElement('div');
        div.id = group;
        div.classList.add("form");
        div.classList.add("tab-content-settings-section");
        let h2 = document.createElement('h3');
        h2.innerText = capitalizeFirstLetter(group);
        div.appendChild(h2);
        let body = document.createElement("div");
        body.id = group+"Body";
        body.classList.add("tab-content-settings-section-body");
        div.appendChild(body);
        let footer = document.createElement("div");
        footer.classList.add("tab-content-settings-section-footer");
        footer.id = group+"Footer";
        div.appendChild(body);
        
        return div;
    },
    createFormControl(labelText, description, type, id, value, requiresRestart) {
        let div = document.createElement('div');
        div.classList.add("formElement", "formElement--label-large");
        let labelElement = document.createElement('label');
        labelElement.setAttribute("title", description)
        labelElement.textContent = labelText;
        labelElement.setAttribute("for", id);
        let control;
        switch(type) {
            case this.FormControlTypes.Double:
                control = this.createDoubleInput(id, value, requiresRestart);
                break;
            case this.FormControlTypes.Int:
                control = this.createNumberInput(id, value, requiresRestart);
                break;
            case this.FormControlTypes.Text:
                control = this.createTextInput(id, value, requiresRestart);
                break;
            case this.FormControlTypes.Radio:
                control = this.createRadioInput(id, value, requiresRestart);
            break;
            case this.FormControlTypes.Combo:
                control = this.createComboInput(id, value, requiresRestart);
            break;
            case this.FormControlTypes.Checkbox:
                control = this.createCheckboxInput(id, value, requiresRestart);
            break;
            case this.FormControlTypes.DateTime:
                control = this.createDateTimeInput(id, value, requiresRestart);
            break;
            case this.FormControlTypes.Date:
                control = this.createDateInput(id, value, requiresRestart);
            break;
            case this.FormControlTypes.Time:
                control = this.createTimeInput(id, value, requiresRestart);
            break;
        }
        control.setAttribute("title", description);
        div.appendChild(labelElement);
        if(control) {
            div.appendChild(control);
        } else {
            div.innerText = " Invalid control type:" + type;
        }
        return {div: div, label: labelElement, control: control};
    },
    createInput(id) {
        let element = document.createElement("input");
        element.id = id;
        return element;
    },
    createTextInput(id, value, requiresRestart) {
        let element = this.createInput(id);
        element.type = "text";
        element.value = value;

        element.onchange = function (element, id) {
            // if(!element.validity.valid) {
            //         return;
            // }
            if(this.debounceer[id])
                clearTimeout(this.debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id, element.value, element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);

        return element;
    },
    createNumberInput(id, value, requiresRestart) {
        const element = this.createInput(id);
        element.value = parseInt(value);
        element.type = "number";
        element.onchange = function (element, id) {
            // if(!element.validity.valid && !element.validity.stepMismatch)
            //     return;
            if(this.debounceer[id])
                clearTimeout(this.debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid && !element.validity.stepMismatch) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id,  parseInt(element.value), element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);
        return element;
    },
    createDoubleInput(id, value, requiresRestart) {
        const element = this.createInput(id);
        element.value = parseFloat(value);
        element.type = "number";
        element.onchange = function (element, id) {
            // if(!element.validity.valid && !element.validity.stepMismatch)
            //     return;
            if(this.debounceer[id])
                clearTimeout(this.debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid && !element.validity.stepMismatch) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id, parseFloat(element.value), element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);
        return element;
    },
    createTimeInput(id, value, requiresRestart) {
        const element = this.createTextInput(id, value);
        element.type = "time";
        return element;
    },
    createDateInput(id, value, requiresRestart) {
        const element = this.createTextInput(id, value);
        element.type = "date";
        return element;
    },
    createDateTimeInput(id, value, requiresRestart) {
        const element = this.createTextInput(id, value);
        element.type = "datetime-local";
        return element;
    },
    createRadioInput(id, group, checked, requiresRestart) {
        let element = this.createInput(id);
        element.type = "radio";
        element.name = group;
        element.checked = checked;
        
        element.onchange = function (element, id) {
            // if(!element.validity.valid) {
            //         return;
            // }
            if(this.debounceer[id])
                clearTimeout(this.debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id, element.checked, element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);

        return element;
    },
    createCheckboxInput(id, checked, requiresRestart) {
        let element = this.createInput(id);
        element.type = "checkbox";
        element.checked = checked;

        element.onchange = function (element, id) {
            // if(!element.validity.valid) {
            //     return;
            // }
            if(this.debounceer[id])
                clearTimeout(this.debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id, element.checked, element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);

        return element;
    },
    createComboInput(id, values, requiresRestart) {
        let element = document.createElement("select");
        element.id = id;
        values.forEach(x => {
            let option = document.createElement("option");
            option.innerText = x["key"];
            option.value = x["value"];
            element.appendChild(option);
        });

        element.onchange = function (element, id) {
            if(this.debounceer[id])
                clearTimeout(debounceer[id]);
            this.debounceer[id] = setTimeout(function(id, element) {
                this.debounceer[id] = undefined;
                if(!element.validity.valid) {
                    saveFail(`Error saving ${element.id}: Error: ${element.validationMessage}`);
                    return;
                }
		        this.callBackExtensions(id, element.value, element);
                if(requiresRestart) {
                    showRestartRequired();
                }
            }.bind(this, id, element), this.debounceerTimeout);
        }.bind(this, element, id);

        return element;
    },
    load(allSettings) {
        if(this.loaded)
            return;
        allSettings["settings"].forEach(x => {
            if(x.internal)
                return;
            this.loadSetting(x);
        });
        this.loaded = true;
    },
    loadSetting(setting) {
        if(this.loaded)
            return;
        let groupElement = document.getElementById(setting.group);
        let appendNewForm = false;
        if(!groupElement) {
            groupElement = this.createForm(setting.group);
            appendNewForm = true;
        }
        switch (setting.profile) {
            case this.SettingProfile.System:
                if(appendNewForm) {
                    systemInfoTab.appendChild(groupElement);
                }
                break;
            default:
                systemError("Invalid settings profile: " + setting.profile);
                return;
        }
        const formControl = this.createFormControl(setting.label, setting.description, setting.type, setting.key, setting.value, setting.requiresRestart);
        const groupBodyElement = document.getElementById(setting.group+"Body");
        groupBodyElement.appendChild(formControl.div);
        this.setSpecialProperties(setting.key, setting.value, formControl);
    },
    setSpecialProperties(key, value, formControl) {
        switch(key) {
            case "playbackRateStep":
                document.getElementById("playbackRateInput").setAttribute("step", value);
                formControl.control.min = 0.0;
                formControl.control.step = 0.01;
                break;
            case "httpChunkSizeMB":
                formControl.control.min = 0.5;
                // formControl.control.step = 1.0;
                break;
            case "scheduleLibraryLoadTime":
                formControl.control.min = "00:00";
                formControl.control.max = "23:59";
                break;
            case "enableMediaManagement":
                mediaManagementEnabled = value;
                break;
            case "viewedThreshold":
                formControl.control.min = 1;
                formControl.control.max = 99;
                formControl.control.step = 1;
                break;
        }
    },
    callBackExtensions(key, value, formControl) {
        let valueMutable = value;
        switch(key) {
            case "enableMediaManagement":
                mediaManagementEnabled = value;
	            showChange(showGlobal);
                break;
        }

        settingChange(key, valueMutable);
    },
    onSaveSuccess(key, value) {
        switch(key) {
            case "settingsBackupDirectory":
                getExported();
                break;
        }
    }
}